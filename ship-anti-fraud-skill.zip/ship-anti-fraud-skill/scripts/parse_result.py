#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
船舶险反欺诈查询结果解析与风险评估脚本（ship-anti-fraud-report skill 配套工具）

用途：
  读取中银保信返回的船舶险反欺诈查询结果文件（*_result.xlsx），一步完成：
  ① 按船分组（一船多行 = 多险种） ② 复合字段结构化解析
  ③ R1-R6 风险规则评估 ④ 风险评分（0-100）与风险类型归纳
  输出标准 JSON（stdout 或 -o 指定文件），供 AI 直接生成解读报告。

用法：
  python3 parse_result.py <result.xlsx> [-o output.json] [--rules interpret-rules.json]

依赖：openpyxl（pip install openpyxl）
规则阈值默认内嵌，与 skill references/interpret-rules.json 保持一致；
--rules 可传入同名配置覆盖阈值。

退出码：0 成功；2 文件格式不符（上传文件/企业格式/无船舶数据）；1 其他错误
"""

import argparse
import json
import os
import re
import sys
from datetime import date

try:
    from openpyxl import load_workbook
except ImportError:
    sys.stderr.write("[错误] 缺少依赖 openpyxl，请先执行: pip install openpyxl\n")
    sys.exit(1)

# ---------------- 默认规则配置（与 references/interpret-rules.json 一致） ----------------

DEFAULT_RULES = {
    "risk_levels": {"high": "高风险", "medium": "中风险", "review": "需人工复核",
                    "notice": "提示关注", "low": "低风险"},
    "rules": {
        "R1": {"name": "倒签单嫌疑",   "level": "high",   "risk_type": "欺诈风险",
               "desc": "近1年存在起保当月即出险的保单且占比超过阈值，存在先出险后投保（倒签单）的欺诈嫌疑",
               "threshold": {"min_pct": 30}},
        "R2": {"name": "高赔付风险",   "level": "high",   "risk_type": "亏损风险",
               "desc": "满期赔付率（已决+未决）有多个年度超过阈值，属高赔付风险标的",
               "threshold": {"ratio": 100, "years": 2}},
        "R3": {"name": "频繁转保",     "level": "medium", "risk_type": "道德风险",
               "desc": "近3年保单涉及保险公司数量较多，存在频繁更换承保公司的情况",
               "threshold": {"count": 3}},
        "R4": {"name": "出险原因集中", "level": "medium", "risk_type": "亏损风险",
               "desc": "近3年同一出险原因多次重复出现，风险集中",
               "threshold": {"same_cause_count": 3}},
        "R5": {"name": "赔案金额异常", "level": "review", "risk_type": "待核实风险",
               "desc": "存在赔案金额/赔案区间记录，建议人工复核赔案明细", "threshold": {}},
        "R6": {"name": "无行业承保记录", "level": "notice", "risk_type": "信息核实风险",
               "desc": "各险种均无近3年行业承保记录，投保信息真实性需人工核实", "threshold": {}},
    },
}

# 评分权重与等级区间（评分 = 命中规则权重之和，按等级区间封顶/托底）
RULE_WEIGHTS = {"R1": 45, "R2": 40, "R3": 20, "R4": 15, "R5": 10, "R6": 5}
LEVEL_BAND_CEIL = {"medium": 39, "review": 19, "notice": 9}
LEVEL_FLOOR = {"high": 40}

# ---------------- 表头识别（关键字匹配，先特殊后一般；表头须去除全部空白含换行） ----------------

# (字段key, 匹配函数)；顺序重要：先匹配含更多关键字的表头
COLUMN_MATCHERS = [
    ("service_no",          lambda h: "查询服务编号" in h),
    ("ship_id_no",          lambda h: "船舶识别号" in h),
    ("imo_no",              lambda h: "IMO" in h.upper()),
    ("name_cn",             lambda h: "船舶中文名" in h),
    ("name_en",             lambda h: "船舶英文名" in h),
    ("insurance_subtype",   lambda h: "险种小类" in h),
    ("loss_ratio_total",    lambda h: "满期赔付率" in h and "已决" in h and "未决" in h),
    ("loss_ratio_paid",     lambda h: "满期赔付率" in h and "已决" in h),
    ("accident_causes",     lambda h: "出险原因" in h),
    ("claim_amounts",       lambda h: "赔案金额" in h),
    ("claim_ranges",        lambda h: "赔案区间" in h),
    ("early_ratio_1m",      lambda h: "起保当月" in h and "出险" in h),
    ("early_ratio_2m",      lambda h: "起保2个月" in h.replace("2个月", "2个月") or ("起保" in h and "2个月" in h and "出险" in h)),
    ("early_ratio_3m",      lambda h: "起保" in h and "3个月" in h and "出险" in h),
    ("insurer_count_3y",    lambda h: "保险公司数量" in h),
    ("latest_insurer_code", lambda h: "保险公司代码" in h),
    ("avg_amount_premium",  lambda h: "单均保额" in h),
    # 人工整理的案例文件可能附带的辅助列（可选）
    ("tonnage",             lambda h: "吨数" in h),
    ("avg_premium",         lambda h: "近3年单均保费" in h and "保额" not in h),
    ("rate_permille",       lambda h: h == "费率"),
    ("rate_per_gt",         lambda h: "单均费率" in h),
]


def norm(s):
    """去除全部空白字符（表头内含换行）"""
    return re.sub(r"\s+", "", str(s)) if s is not None else ""


def cell_text(v):
    """单元格统一转文本；None -> ''；数字避免科学计数法"""
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v).strip()


def is_null_text(s):
    return s == "" or s == "(null)" or s.lower() == "null"


# ---------------- 复合值解析 ----------------

def parse_ratio_years(raw):
    """'Z,0,0,0' -> {raw, years:[...]}; (null)/空 -> None"""
    if is_null_text(raw):
        return None
    return {"raw": raw, "years": [x.strip() for x in raw.split(",")]}


def parse_count_pct(raw):
    """'0,0.00%' / '1,100%' -> {raw, count, pct}; (null) -> None"""
    if is_null_text(raw):
        return None
    m = re.match(r"^(\d+)\s*,\s*([\d.]+)%$", raw)
    if m:
        return {"raw": raw, "count": int(m.group(1)), "pct": float(m.group(2))}
    return {"raw": raw}


def parse_amount_premium(raw):
    """'35000000,148000' -> {raw, amount, premium, rate_permille}; (null) -> None"""
    if is_null_text(raw):
        return None
    parts = [p.strip() for p in raw.split(",")]
    if len(parts) == 2:
        try:
            amount, premium = float(parts[0]), float(parts[1])
            rate = round(premium / amount * 1000, 2) if amount else None
            return {"raw": raw, "amount": parts[0], "premium": parts[1], "rate_permille": rate}
        except ValueError:
            pass
    return {"raw": raw}


def parse_pairs(raw, unit_word):
    """通用 'A|n,B|n' 或 'A n{unit_word}' 解析 -> {raw, items:[{label,count}]}; (null) -> None"""
    if is_null_text(raw):
        return None
    items = []
    # 优先按 | 分隔的规范格式
    if "|" in raw:
        for part in re.split(r"[,，、]", raw):
            part = part.strip()
            if not part:
                continue
            if "|" in part:
                label, _, cnt = part.rpartition("|")
                items.append({"label": label.strip(), "count": _to_int(cnt)})
            else:
                m = re.match(r"^(.*?)(\d+)\s*%s$" % unit_word, part)
                if m:
                    items.append({"label": m.group(1).strip(), "count": int(m.group(2))})
                else:
                    items.append({"label": part, "count": 1})
    else:
        # 兼容 '搁浅2次、碰撞1次' / '50万以下2件' 风格
        for part in re.split(r"[,，、]", raw):
            part = part.strip()
            if not part:
                continue
            m = re.match(r"^(.*?)(\d+)\s*%s$" % unit_word, part)
            if m:
                items.append({"label": m.group(1).strip(), "count": int(m.group(2))})
            else:
                items.append({"label": part, "count": 1})
    return {"raw": raw, "items": items}


def _to_int(s):
    try:
        return int(float(s))
    except (TypeError, ValueError):
        return None


def parse_claim_amounts(raw):
    """赔案金额：单数值=累计金额；逗号分隔=各笔金额。返回 {raw, total, items}"""
    if is_null_text(raw):
        return None
    parts = [p.strip() for p in re.split(r"[,，]", raw) if p.strip()]
    nums = []
    for p in parts:
        try:
            nums.append(float(p))
        except ValueError:
            return {"raw": raw}
    if len(nums) == 1:
        return {"raw": raw, "total": nums[0], "single_cumulative": True}
    return {"raw": raw, "total": sum(nums), "items": nums, "single_cumulative": False}


def parse_count_field(raw):
    """保险公司数量：数值或 (null)"""
    if is_null_text(raw):
        return None
    return _to_int(raw)


# ---------------- 规则评估 ----------------

def years_over_ratio(ratio_field, ratio):
    if not ratio_field or "years" not in ratio_field:
        return 0
    n = 0
    for v in ratio_field["years"]:
        try:
            if float(v) >= ratio:
                n += 1
        except ValueError:
            continue
    return n


def evaluate_ship(policies, rules):
    """逐险种评估 R1-R6，返回 {risk_level, score, hits, risk_types}"""
    R = rules["rules"]
    hits = []

    for p in policies:
        sub = p.get("insurance_subtype") or "未知险种"

        # R1 倒签单嫌疑
        e1 = p.get("early_ratio_1m")
        if e1 and isinstance(e1.get("pct"), (int, float)) and e1["pct"] >= R["R1"]["threshold"]["min_pct"]:
            hits.append({"rule": "R1", "name": R["R1"]["name"], "level": "high",
                         "risk_type": R["R1"]["risk_type"], "subtype": sub,
                         "detail": "%s：近1年起保当月出险保单 %s 单、占比 %s%%（阈值 %s%%）" % (
                             sub, e1.get("count"), e1.get("pct"), R["R1"]["threshold"]["min_pct"])})

        # R2 高赔付风险（已决+未决 多年度超阈值）
        rt = p.get("loss_ratio_total")
        y2 = years_over_ratio(rt, R["R2"]["threshold"]["ratio"])
        if y2 >= R["R2"]["threshold"]["years"]:
            hits.append({"rule": "R2", "name": R["R2"]["name"], "level": "high",
                         "risk_type": R["R2"]["risk_type"], "subtype": sub,
                         "detail": "%s：满期赔付率（已决+未决）有 %d 个年度 ≥ %d%%（%s）" % (
                             sub, y2, R["R2"]["threshold"]["ratio"], rt.get("raw") if rt else "")})

        # R3 频繁转保
        ic = p.get("insurer_count_3y")
        if isinstance(ic, int) and ic >= R["R3"]["threshold"]["count"]:
            hits.append({"rule": "R3", "name": R["R3"]["name"], "level": "medium",
                         "risk_type": R["R3"]["risk_type"], "subtype": sub,
                         "detail": "%s：近3年保单涉及 %d 家保险公司（阈值 %d 家）" % (
                             sub, ic, R["R3"]["threshold"]["count"])})

        # R4 出险原因集中
        ac = p.get("accident_causes")
        if ac and isinstance(ac.get("items"), list):
            for it in ac["items"]:
                if isinstance(it.get("count"), int) and it["count"] >= R["R4"]["threshold"]["same_cause_count"]:
                    hits.append({"rule": "R4", "name": R["R4"]["name"], "level": "medium",
                                 "risk_type": R["R4"]["risk_type"], "subtype": sub,
                                 "detail": "%s：出险原因「%s」近3年出现 %d 次" % (sub, it["label"], it["count"])})

        # R5 赔案金额异常（存在赔案记录即提示人工复核）
        if p.get("claim_amounts") or p.get("claim_ranges"):
            amt = p["claim_amounts"]["raw"] if p.get("claim_amounts") else ""
            rng = p["claim_ranges"]["raw"] if p.get("claim_ranges") else ""
            hits.append({"rule": "R5", "name": R["R5"]["name"], "level": "review",
                         "risk_type": R["R5"]["risk_type"], "subtype": sub,
                         "detail": "%s：存在赔案记录%s%s，建议人工复核明细" % (
                             sub, "（赔案金额：%s）" % amt if amt else "",
                             "（赔案区间：%s）" % rng if rng else "")})

    # R6 无行业承保记录（全部险种赔付率均为 Z 或空）
    if policies:
        def no_record(p):
            lp, lt = p.get("loss_ratio_paid"), p.get("loss_ratio_total")
            if lp is None and lt is None:
                return True
            for f in (lp, lt):
                if f and "years" in f and len(f["years"]) > 0 and all(v.strip().upper() == "Z" for v in f["years"]):
                    return True
            return False
        if all(no_record(p) for p in policies):
            hits.append({"rule": "R6", "name": R["R6"]["name"], "level": "notice",
                         "risk_type": R["R6"]["risk_type"], "subtype": "全部险种",
                         "detail": "该船近3年无行业承保理赔记录（各险种赔付率均为 Z 或空），投保信息真实性需人工核实"})

    # 等级聚合：high > medium > review > notice
    order = ["high", "medium", "review", "notice"]
    level = "low"
    for lv in order:
        if any(h["level"] == lv for h in hits):
            level = lv
            break

    # 评分：权重累加 + 等级区间封顶/托底
    score = sum(RULE_WEIGHTS[h["rule"]] for h in hits)
    score = min(score, 100)
    if level in LEVEL_BAND_CEIL:
        score = min(score, LEVEL_BAND_CEIL[level])
    elif level in LEVEL_FLOOR:
        score = max(score, LEVEL_FLOOR[level])
    else:  # low
        score = 0

    risk_types = []
    for h in hits:
        if h["risk_type"] not in risk_types:
            risk_types.append(h["risk_type"])

    return {"risk_level": level, "risk_level_text": rules["risk_levels"][level],
            "score": score, "risk_types": risk_types, "hits": hits}


# ---------------- 主流程 ----------------

def load_rules(path=None):
    if path and os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            cfg = json.load(f)
        # 合并 risk_type（外部规则文件可能无该字段）
        for rid, meta in cfg.get("rules", {}).items():
            if rid in DEFAULT_RULES["rules"]:
                meta.setdefault("risk_type", DEFAULT_RULES["rules"][rid]["risk_type"])
                meta.setdefault("desc", DEFAULT_RULES["rules"][rid]["desc"])
        cfg.setdefault("risk_levels", DEFAULT_RULES["risk_levels"])
        return cfg
    return DEFAULT_RULES


def load_insurer_codes(script_dir):
    for cand in [os.path.join(script_dir, "..", "references", "insurer-codes.json"),
                 os.path.join(script_dir, "insurer-codes.json")]:
        if os.path.exists(cand):
            with open(cand, encoding="utf-8") as f:
                return json.load(f)
    return {}


def find_result_sheet(wb):
    """找含「险种小类」表头的工作表；同时识别企业格式"""
    for ws in wb.worksheets:
        headers = []
        for row in ws.iter_rows(min_row=1, max_row=1, values_only=True):
            headers = [norm(c) for c in row]
            break
        joined = "|".join(headers)
        if "险种小类" in joined and "满期赔付率" in joined:
            return ws, headers
        if joined.startswith("A01") or "统一社会信用代码" in joined or "企业名称" in joined:
            return None, "enterprise"
    return None, "no-match"


def parse_file(path, rules, insurer_codes):
    wb = load_workbook(path, read_only=True, data_only=True)
    ws, info = find_result_sheet(wb)

    if ws is None:
        if info == "enterprise":
            raise SystemExit("[格式不符] 该文件为企业格式（A01_ 前缀），本技能仅支持船舶险查询结果文件。")
        raise SystemExit("[格式不符] 未找到含「险种小类」「满期赔付率」表头的工作表。"
                         "请确认上传的是中银保信返回的 *_result.xlsx 结果文件（而非仅含船舶四要素的查询上传文件）。")

    # 建立列映射
    col_map = {}
    for idx, h in enumerate(info):
        if not h:
            continue
        for key, matcher in COLUMN_MATCHERS:
            if key not in col_map and matcher(h):
                col_map[key] = idx
                break

    required = ["insurance_subtype", "loss_ratio_paid", "loss_ratio_total"]
    missing = [k for k in required if k not in col_map]
    if missing:
        raise SystemExit("[格式不符] 缺少关键列：%s。请确认是船舶险 result 结果文件。" % "、".join(missing))

    # 逐行读取并按船分组
    ships = {}
    order = []
    rows = list(ws.iter_rows(min_row=2, values_only=True))
    for row in rows:
        if row is None or all(c is None or str(c).strip() in ("", "(null)") for c in row):
            continue

        # 识别文件下方的「指标释义/案例说明」区（案例文件布局），遇到即停止数据解析
        head_text = "|".join(cell_text(c) for c in row[:8] if c is not None)
        if "指标名称" in head_text or "指标含义" in head_text or head_text.startswith("统计区间"):
            break

        def get(key):
            idx = col_map.get(key)
            return cell_text(row[idx]) if idx is not None and idx < len(row) else ""

        sub = get("insurance_subtype")
        ship_id, imo = get("ship_id_no"), get("imo_no")
        name_cn, name_en = get("name_cn"), get("name_en")
        if not sub and not ship_id and not imo and not name_cn and not name_en:
            continue

        key = "|".join([ship_id, imo, name_cn, name_en])
        if key not in ships:
            ships[key] = {"conditions": {"ship_id_no": ship_id or None, "imo_no": imo or None,
                                         "name_cn": name_cn or None, "name_en": name_en or None},
                          "service_no": get("service_no") or None, "policies": []}
            order.append(key)

        ap = get("avg_amount_premium")
        apf = parse_amount_premium(ap)
        # 辅助列合并：部分人工整理文件中「近3年单均保额保费」列仅含保额，保费/费率在独立辅助列
        if apf and "amount" not in apf:
            aux_prem, aux_rate = get("avg_premium"), get("rate_permille")
            try:
                amt = float(apf["raw"])
                if aux_prem and not is_null_text(aux_prem):
                    prem = float(aux_prem)
                    apf = {"raw": "%s,%s" % (apf["raw"], aux_prem), "amount": apf["raw"],
                           "premium": aux_prem,
                           "rate_permille": round(prem / amt * 1000, 2) if amt else None}
                elif aux_rate and not is_null_text(aux_rate):
                    r = float(aux_rate)
                    if r < 0.1:  # 小数表示比值（如 0.00422 = 4.22‰）
                        apf["rate_permille"] = round(r * 1000, 2)
            except ValueError:
                pass
        code = get("latest_insurer_code")
        policy = {
            "insurance_subtype": sub or "未知险种",
            "loss_ratio_paid": parse_ratio_years(get("loss_ratio_paid")),
            "loss_ratio_total": parse_ratio_years(get("loss_ratio_total")),
            "accident_causes": parse_pairs(get("accident_causes"), "次"),
            "claim_amounts": parse_claim_amounts(get("claim_amounts")),
            "claim_ranges": parse_pairs(get("claim_ranges"), "件"),
            "early_ratio_1m": parse_count_pct(get("early_ratio_1m")),
            "early_ratio_2m": parse_count_pct(get("early_ratio_2m")),
            "early_ratio_3m": parse_count_pct(get("early_ratio_3m")),
            "insurer_count_3y": parse_count_field(get("insurer_count_3y")),
            "latest_insurer_code": code or None,
            "latest_insurer_name": insurer_codes.get(code) if code else None,
            "avg_amount_premium": apf,
        }
        # 可选辅助列
        tn = get("tonnage")
        if tn:
            policy["tonnage"] = tn
        rgt = get("rate_per_gt")
        if rgt:
            policy["rate_per_gt"] = rgt
        ships[key]["policies"].append(policy)

    wb.close()
    if not ships:
        raise SystemExit("[格式不符] 文件中没有有效的船舶数据行。")

    result_ships = []
    for key in order:
        s = ships[key]
        evaluation = evaluate_ship(s["policies"], rules)
        result_ships.append({
            "conditions": s["conditions"],
            "service_no": s["service_no"],
            "ship_name": s["conditions"]["name_cn"] or s["conditions"]["name_en"]
                         or s["conditions"]["ship_id_no"] or "未知船舶",
            "policy_count": len(s["policies"]),
            "policies": s["policies"],
            "evaluation": evaluation,
        })
    return result_ships


def main():
    ap = argparse.ArgumentParser(description="船舶险反欺诈 result 文件解析与风险评估")
    ap.add_argument("file", help="中银保信返回的 *_result.xlsx 文件路径")
    ap.add_argument("-o", "--output", help="输出 JSON 文件路径（默认打印到 stdout）")
    ap.add_argument("--rules", help="interpret-rules.json 路径（可选，覆盖默认阈值）")
    args = ap.parse_args()

    if not os.path.exists(args.file):
        sys.stderr.write("[错误] 文件不存在: %s\n" % args.file)
        sys.exit(1)

    script_dir = os.path.dirname(os.path.abspath(__file__))
    rules = load_rules(args.rules)
    insurer_codes = load_insurer_codes(script_dir)

    ships = parse_file(args.file, rules, insurer_codes)

    output = {
        "skill": "ship-anti-fraud-report",
        "file": os.path.basename(args.file),
        "generated_at": date.today().isoformat(),
        "statistic_range": "当年及过去三年（4个年度，顺序：当年、Y-1、Y-2、Y-3）",
        "ship_count": len(ships),
        "summary": [{"ship_name": s["ship_name"], "risk_level": s["evaluation"]["risk_level_text"],
                     "score": s["evaluation"]["score"],
                     "risk_types": s["evaluation"]["risk_types"]} for s in ships],
        "ships": ships,
        "usage": "请基于本 JSON 按 references/report-template.md 模板，为每艘船舶生成一份解读报告",
    }

    text = json.dumps(output, ensure_ascii=False, indent=2)
    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(text)
        sys.stderr.write("[完成] 已解析 %d 艘船舶，结果写入 %s\n" % (len(ships), args.output))
    else:
        print(text)


if __name__ == "__main__":
    main()
