// SQLite 封装（基于 sql.js，纯 WASM，无需原生编译）
// 数据库以文件形式持久化到 server/data/app.db
//
// Schema 版本（PRAGMA user_version）：
//   v1: ships + pending_queries(ship_id_no/imo_no/name_cn/name_en) + processed_results(ships)
//   v2: companies + pending_queries(query_type/name/credit_code/insurance_type) + processed_results(records)
// 升级到 v2 时会做一次性 .bak-v1 备份并重建，v1 数据视为已弃用。
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.resolve(__dirname, '../data');
const DB_PATH = process.env.DB_PATH || path.join(DATA_DIR, 'app.db');
const SCHEMA_VERSION = 2;

let SQL = null;
let db = null;

export async function initDb() {
  if (db) return db;
  SQL = await initSqlJs();
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (fs.existsSync(DB_PATH)) {
    const file = fs.readFileSync(DB_PATH);
    db = new SQL.Database(new Uint8Array(file));
  } else {
    db = new SQL.Database();
  }
  createSchema();
  persist();
  return db;
}

function getSchemaVersion() {
  const r = db.exec('PRAGMA user_version');
  return r.length ? r[0].values[0][0] : 0;
}

function createSchema() {
  const current = getSchemaVersion();

  // v1 → v2：备份旧库，丢弃弃用的 ship 相关表
  if (current < 2 && current >= 1 && fs.existsSync(DB_PATH)) {
    const bak = DB_PATH + '.bak-v1';
    if (!fs.existsSync(bak)) {
      try { fs.copyFileSync(DB_PATH, bak); } catch { /* 备份失败不阻塞 */ }
    }
  }
  if (current < 2) {
    db.run('DROP TABLE IF EXISTS ships');
    db.run('DROP TABLE IF EXISTS pending_queries');
    db.run('DROP TABLE IF EXISTS processed_results');
  }

  // 本地企业记录（v2）
  db.run(`
    CREATE TABLE IF NOT EXISTS companies (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      query_type TEXT DEFAULT '',
      name TEXT DEFAULT '',
      credit_code TEXT DEFAULT '',
      insurance_type TEXT DEFAULT '',
      result_data TEXT DEFAULT '{}',
      last_query_time TEXT,
      created_at TEXT
    );
  `);
  db.run('CREATE INDEX IF NOT EXISTS idx_companies_name ON companies(name);');
  db.run('CREATE INDEX IF NOT EXISTS idx_companies_credit ON companies(credit_code);');

  // 待查询队列（v2）
  db.run(`
    CREATE TABLE IF NOT EXISTS pending_queries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      org TEXT NOT NULL,
      requested_by TEXT,
      query_type TEXT DEFAULT '',
      name TEXT DEFAULT '',
      credit_code TEXT DEFAULT '',
      insurance_type TEXT DEFAULT '',
      status TEXT DEFAULT 'pending',
      created_at TEXT,
      exported_at TEXT,
      export_key TEXT,
      result_file TEXT,
      result_at TEXT
    );
  `);

  // 已处理结果记录（v2：ships→records）
  db.run(`
    CREATE TABLE IF NOT EXISTS processed_results (
      key TEXT PRIMARY KEY,
      processed_at TEXT,
      org TEXT,
      records INTEGER,
      pending INTEGER
    );
  `);

  db.run(`PRAGMA user_version = ${SCHEMA_VERSION}`);
}

export function persist() {
  if (!db) return;
  const data = db.export();
  fs.writeFileSync(DB_PATH, Buffer.from(data));
}

export function all(sql, params = []) {
  const stmt = db.prepare(sql);
  if (params.length) stmt.bind(params);
  const rows = [];
  while (stmt.step()) rows.push(stmt.getAsObject());
  stmt.free();
  return rows;
}

export function get(sql, params = []) {
  return all(sql, params)[0] || null;
}

export function run(sql, params = []) {
  const stmt = db.prepare(sql);
  if (params.length) stmt.bind(params);
  stmt.step();
  stmt.free();
  persist();
}

export function runReturnId(sql, params = []) {
  const stmt = db.prepare(sql);
  if (params.length) stmt.bind(params);
  stmt.step();
  stmt.free();
  const row = get('SELECT last_insert_rowid() AS id');
  persist();
  return row ? row.id : null;
}

export function getDb() {
  return db;
}