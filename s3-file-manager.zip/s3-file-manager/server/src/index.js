import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import filesRouter from './routes/files.js';
import companiesRouter from './routes/companies.js';
import { authMiddleware, authRequired, handleLogin, handleAuthRequired } from './auth.js';
import { initDb } from './db.js';

const app = express();
app.use(cors());
app.use(express.json());

// ---- 公开接口 ----
app.post('/api/auth/login', handleLogin);
app.get('/api/auth/required', handleAuthRequired);

app.get('/api/health', (req, res) =>
  res.json({ status: 'ok', time: new Date().toISOString() }));

// 当前登录人信息（含机构）
app.get('/api/me', authMiddleware, (req, res) =>
  res.json({ status: 'ok', username: req.user.username, org: req.user.org }));

// ---- 受保护接口（若启用口令则需 Bearer）----
app.use('/api', authMiddleware, filesRouter);
app.use('/api/companies', authMiddleware, companiesRouter);

// ---- 生产环境：托管已构建的前端（npm run build 之后）----
const webDist = path.resolve(process.cwd(), '../web/dist');
if (fs.existsSync(webDist)) {
  app.use(express.static(webDist));
  app.get(/^(?!\/api).*/, (req, res) =>
    res.sendFile(path.join(webDist, 'index.html')));
}

const PORT = process.env.PORT || 3001;

async function main() {
  await initDb();
  app.listen(PORT, () => {
    console.log(`[s3-file-manager] server listening on http://localhost:${PORT}`);
    if (!process.env.S3_BUCKET) {
      console.warn('[warn] S3_BUCKET 未配置，请在 .env 中填写后重启。');
    }
    console.log('[info] 企业查询的「上传待查询 Excel / 检索导入返回 Excel」均为手动触发（前端按钮）。');
  });
}

main().catch((e) => {
  console.error('[fatal] 启动失败:', e);
  process.exit(1);
});
