// 登录与机构体系
// 支持两种模式：
//  - 多用户模式：环境变量 USERS 为 JSON 数组 [{username,password,org}, ...]
//  - 单口令模式：仅配置 APP_PASSWORD，机构取 DEFAULT_ORG 或 DEFAULT
//  - 无鉴权模式：未配置任何口令，机构取 DEFAULT
import crypto from 'crypto';

function parseUsers() {
  const raw = process.env.USERS;
  if (!raw) return [];
  try {
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? arr : [];
  } catch {
    return [];
  }
}

function secret() {
  return process.env.APP_PASSWORD || 'no-auth-secret';
}

export function authRequired() {
  const users = parseUsers();
  if (users.length) return true;
  return !!process.env.APP_PASSWORD;
}

function sign(payloadB64) {
  return crypto.createHmac('sha256', secret()).update(payloadB64).digest('base64url');
}

function makeToken(username, org) {
  const payload = Buffer.from(JSON.stringify({ username, org, iat: Date.now() })).toString('base64url');
  return payload + '.' + sign(payload);
}

export function verifyToken(token) {
  if (!token || typeof token !== 'string' || !token.includes('.')) return null;
  const [payloadB64, sig] = token.split('.');
  const expected = sign(payloadB64);
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length) return null;
  if (!crypto.timingSafeEqual(a, b)) return null;
  try {
    return JSON.parse(Buffer.from(payloadB64, 'base64url').toString('utf8'));
  } catch {
    return null;
  }
}

// POST /api/auth/login
export function handleLogin(req, res) {
  const { username, password } = req.body || {};
  const users = parseUsers();

  if (users.length) {
    const u = users.find((x) => x.username === username && x.password === password);
    if (!u) return res.status(401).json({ status: 'error', message: '用户名或口令错误' });
    const token = makeToken(u.username, u.org);
    return res.json({ status: 'ok', token, username: u.username, org: u.org, authRequired: true });
  }

  if (process.env.APP_PASSWORD) {
    if (password !== process.env.APP_PASSWORD) {
      return res.status(401).json({ status: 'error', message: '口令错误' });
    }
    const org = process.env.DEFAULT_ORG || 'DEFAULT';
    const token = makeToken('admin', org);
    return res.json({ status: 'ok', token, username: 'admin', org, authRequired: true });
  }

  // 无鉴权
  const token = makeToken('anonymous', 'DEFAULT');
  return res.json({ status: 'ok', token, username: 'anonymous', org: 'DEFAULT', authRequired: false });
}

export function handleAuthRequired(req, res) {
  res.json({ required: authRequired() });
}

export function authMiddleware(req, res, next) {
  if (!authRequired()) {
    req.user = { username: 'anonymous', org: 'DEFAULT' };
    return next();
  }
  const h = req.headers['authorization'] || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : '';
  const payload = verifyToken(token);
  if (!payload) return res.status(401).json({ status: 'error', message: '未授权，请先登录' });
  req.user = { username: payload.username, org: payload.org };
  next();
}
