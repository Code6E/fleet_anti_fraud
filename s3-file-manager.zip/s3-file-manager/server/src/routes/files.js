import express from 'express';
import multer from 'multer';
import {
  BUCKET, listObjects, getObject, putObject,
  deleteObject, deleteFolder, copyObject, createFolder, listAllKeys,
} from '../s3.js';

const router = express.Router();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 1024 * 1024 * 500, files: 50 }, // 单文件 500MB，最多 50 个
});

// 配置信息（不含任何密钥）
router.get('/config', (req, res) => {
  res.json({
    status: 'ok',
    bucket: BUCKET,
    endpoint: process.env.S3_ENDPOINT || '(AWS S3)',
    region: process.env.S3_REGION || 'us-east-1',
    authRequired: !!process.env.APP_PASSWORD,
  });
});

// 列表
router.get('/files', async (req, res) => {
  try {
    const prefix = typeof req.query.prefix === 'string' ? req.query.prefix : '';
    const data = await listObjects(prefix);
    res.json({ status: 'ok', ...data });
  } catch (e) {
    res.status(500).json({ status: 'error', message: e.message });
  }
});

// 下载
router.get('/files/download', async (req, res) => {
  try {
    const key = req.query.key;
    if (!key) return res.status(400).json({ status: 'error', message: '缺少 key' });
    const { stream, rawBody, contentType, contentLength, fileName } = await getObject(key);
    res.setHeader('Content-Type', contentType);
    res.setHeader('Content-Disposition',
      `attachment; filename*=UTF-8''${encodeURIComponent(fileName)}`);
    if (contentLength) res.setHeader('Content-Length', String(contentLength));
    if (stream) return stream.pipe(res);
    const buf = await rawBody.transformToByteArray();
    res.send(Buffer.from(buf));
  } catch (e) {
    res.status(500).json({ status: 'error', message: e.message });
  }
});

// 上传（支持多文件，query.prefix 为目标目录）
router.post('/files/upload', upload.array('files', 50), async (req, res) => {
  try {
    const prefix = (req.query.prefix && typeof req.query.prefix === 'string') ? req.query.prefix : '';
    const base = prefix.endsWith('/') || prefix === '' ? prefix : prefix + '/';
    const saved = [];
    for (const f of req.files || []) {
      const key = base + f.originalname;
      await putObject(key, f.buffer, f.mimetype || 'application/octet-stream');
      saved.push(key);
    }
    res.json({ status: 'ok', saved });
  } catch (e) {
    res.status(500).json({ status: 'error', message: e.message });
  }
});

// 删除（文件或文件夹，由 type 决定）
router.delete('/files', async (req, res) => {
  try {
    const { key, type } = req.body || {};
    if (!key) return res.status(400).json({ status: 'error', message: '缺少 key' });
    if (type === 'folder') {
      const n = await deleteFolder(key);
      return res.json({ status: 'ok', deleted: n });
    }
    await deleteObject(key);
    res.json({ status: 'ok', deleted: 1 });
  } catch (e) {
    res.status(500).json({ status: 'error', message: e.message });
  }
});

// 重命名（文件或文件夹）
router.post('/files/rename', async (req, res) => {
  try {
    const { from, to, type } = req.body || {};
    if (!from || !to) return res.status(400).json({ status: 'error', message: '缺少 from/to' });
    if (type === 'folder') {
      const srcPrefix = from.endsWith('/') ? from : from + '/';
      const destPrefix = to.endsWith('/') ? to : to + '/';
      const keys = await listAllKeys(srcPrefix);
      for (const k of keys) {
        const newKey = destPrefix + k.slice(srcPrefix.length);
        await copyObject(k, newKey);
      }
      if (keys.length > 0) await deleteFolder(srcPrefix);
      else { await copyObject(srcPrefix, destPrefix); await deleteObject(srcPrefix); }
      return res.json({ status: 'ok', copied: keys.length });
    }
    await copyObject(from, to);
    await deleteObject(from);
    res.json({ status: 'ok' });
  } catch (e) {
    res.status(500).json({ status: 'error', message: e.message });
  }
});

// 新建文件夹
router.post('/files/folder', async (req, res) => {
  try {
    const { prefix, name } = req.body || {};
    if (!name) return res.status(400).json({ status: 'error', message: '缺少 name' });
    const key = await createFolder(prefix || '', name);
    res.json({ status: 'ok', key });
  } catch (e) {
    res.status(500).json({ status: 'error', message: e.message });
  }
});

export default router;
