import express from 'express';
import { all, get, runReturnId } from '../db.js';
import { exportPending, importResults } from '../scheduler.js';

const router = express.Router();

// 规整查询条件（4 个企业维度字段）
function normalize(body = {}) {
  const trim = (v) => (typeof v === 'string' ? v.trim() : (v == null ? '' : String(v)));
  return {
    query_type: trim(body.query_type),
    name: trim(body.name),
    credit_code: trim(body.credit_code),
    insurance_type: trim(body.insurance_type),
  };
}

// 1) 本地查询（按任一项或多项；提供的字段间为 AND）
router.post('/query', (req, res) => {
  const c = normalize(req.body);
  const clauses = [];
  const params = [];
  if (c.query_type) { clauses.push('query_type = ?'); params.push(c.query_type); }
  if (c.name) { clauses.push('name = ?'); params.push(c.name); }
  if (c.credit_code) { clauses.push('credit_code = ?'); params.push(c.credit_code); }
  if (c.insurance_type) { clauses.push('insurance_type = ?'); params.push(c.insurance_type); }
  if (!clauses.length) {
    return res.status(400).json({ status: 'error', message: '请至少填写一项查询条件' });
  }
  const results = all(
    `SELECT id, query_type, name, credit_code, insurance_type, last_query_time
     FROM companies WHERE ${clauses.join(' AND ')}`,
    params,
  );
  if (results.length) {
    return res.json({ status: 'ok', found: true, results, queriedAt: new Date().toISOString() });
  }
  return res.json({
    status: 'ok',
    found: false,
    conditions: c,
    message: '本地未找到相关企业。可确认向中银保信发起查询，查询结果将于次日返回。',
  });
});

// 2) 确认查询：录入待查询（记录当前登录机构与操作人）
router.post('/pending', (req, res) => {
  const c = normalize(req.body);
  if (!c.query_type && !c.name && !c.credit_code && !c.insurance_type) {
    return res.status(400).json({ status: 'error', message: '请至少填写一项查询条件' });
  }
  const org = req.user.org;
  const by = req.user.username;
  // 同机构同条件且尚未完成则不重复录入
  const existing = get(
    `SELECT id FROM pending_queries
     WHERE org=? AND status IN ('pending','exported')
       AND COALESCE(query_type,'')=? AND COALESCE(name,'')=?
       AND COALESCE(credit_code,'')=? AND COALESCE(insurance_type,'')=?`,
    [org, c.query_type, c.name, c.credit_code, c.insurance_type],
  );
  if (existing) {
    return res.json({ status: 'ok', id: existing.id, duplicated: true, message: '该条件已在待查询队列中' });
  }
  const id = runReturnId(
    `INSERT INTO pending_queries (org, requested_by, query_type, name, credit_code, insurance_type, status, created_at)
     VALUES (?,?,?,?,?,?,'pending',?)`,
    [org, by, c.query_type, c.name, c.credit_code, c.insurance_type, new Date().toISOString()],
  );
  return res.json({ status: 'ok', id, org, message: `已加入待查询队列（机构：${org}），将由管理员手动触发上传至 S3` });
});

// 待查询列表（可按 status 过滤）
router.get('/pending', (req, res) => {
  const status = typeof req.query.status === 'string' ? req.query.status : null;
  const rows = status
    ? all('SELECT * FROM pending_queries WHERE status=? ORDER BY id DESC', [status])
    : all('SELECT * FROM pending_queries ORDER BY id DESC');
  res.json({ status: 'ok', rows });
});

// 本地企业记录列表
router.get('/', (req, res) => {
  const rows = all(
    'SELECT id, query_type, name, credit_code, insurance_type, last_query_time FROM companies ORDER BY id DESC LIMIT 500',
  );
  res.json({ status: 'ok', rows });
});

// 手动触发（便于验证，不依赖真实时间）
router.post('/admin/export-now', async (req, res) => {
  try {
    const r = await exportPending(req.body?.date);
    res.json({ status: 'ok', ...r });
  } catch (e) {
    res.status(500).json({ status: 'error', message: e.message });
  }
});

router.post('/admin/import-now', async (req, res) => {
  try {
    const r = await importResults(req.body?.date);
    res.json({ status: 'ok', ...r });
  } catch (e) {
    if (e.code === 'NO_RESULT') {
      return res.json({ status: 'ok', imported: [], message: e.message });
    }
    res.status(500).json({ status: 'error', message: e.message });
  }
});

export default router;