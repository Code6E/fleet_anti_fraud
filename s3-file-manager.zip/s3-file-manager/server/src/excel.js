// Excel 读写（物流/货运企业查询格式）
// 待查询文件列（顺序即导出顺序）：
//   查询类别 | 名称 | 证件号码 | 险种
// 结果文件（中银保信返回）：在前 4 列基础上追加 14 列业务字段（序号/赔付率/保费/保单最大保额/起运地/目的地 等）
import ExcelJS from 'exceljs';

export const QUERY_HEADERS = ['查询类别', '名称', '证件号码', '险种'];
export const QUERY_KEYS = ['query_type', 'name', 'credit_code', 'insurance_type'];

function cellToString(v) {
  if (v == null) return '';
  if (typeof v === 'object') {
    if (v.text != null) return String(v.text);
    if (v.richText) return v.richText.map((t) => t.text).join('');
    if (v instanceof Date) return v.toISOString();
    return String(v);
  }
  if (typeof v === 'number') return String(v);
  return String(v).trim();
}

// 由待查询行（含 query_type/name/credit_code/insurance_type）生成 xlsx 缓冲
export async function buildQueryExcel(rows) {
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('queries');
  ws.columns = QUERY_KEYS.map((k, i) => ({ header: QUERY_HEADERS[i], key: k, width: 26 }));
  for (const r of rows) {
    ws.addRow({
      query_type: r.query_type || '',
      name: r.name || '',
      credit_code: r.credit_code || '',
      insurance_type: r.insurance_type || '',
    });
  }
  const buf = await wb.xlsx.writeBuffer();
  return Buffer.from(buf);
}

// 解析结果文件缓冲，返回 [{conditions, resultData}]
// - conditions 仅取 4 个查询关键列（用于匹配待查询 / 本地检索）
// - resultData 存整行所有列（包含 18 列完整字段，供前端详情展示）
export async function parseResultExcel(buffer) {
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.load(buffer);
  const ws = wb.worksheets[0];
  if (!ws) return [];

  const colMap = {};
  ws.getRow(1).eachCell((cell, colNumber) => {
    colMap[String(cell.value).trim()] = colNumber;
  });

  const rows = [];
  ws.eachRow((row, rowNumber) => {
    if (rowNumber === 1) return;
    const obj = {};
    for (const [h, col] of Object.entries(colMap)) {
      obj[h] = cellToString(row.getCell(col).value);
    }
    const conditions = {
      query_type: obj['查询类别'] || '',
      name: obj['名称'] || '',
      credit_code: obj['证件号码'] || '',
      insurance_type: obj['险种'] || '',
    };
    // 跳过四列全空行
    if (!conditions.query_type && !conditions.name && !conditions.credit_code && !conditions.insurance_type) return;
    rows.push({ conditions, resultData: obj });
  });
  return rows;
}