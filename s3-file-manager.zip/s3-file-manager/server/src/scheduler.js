// 物流/货运企业查询 Excel 的「上传待查询」与「检索导入返回结果」均改为【手动触发】：
//  - exportPending() / importResults() 仍由前端“手动触发”按钮调用（见 routes/companies.js 的 admin 接口）
//  - 不再使用 cron 自动定时，避免无人值守时误传/误读第三方结果
//  - 返回结果文件由第三方放到 S3 的 download/ 目录，命名形如 {机构}_{YYYYMMDD}{分公司名}_result.xlsx
import path from 'path';
import { BUCKET, putObject, getObject, listObjects } from './s3.js';
import { all, get, run, runReturnId, persist } from './db.js';
import { buildQueryExcel, parseResultExcel } from './excel.js';

// 待查询文件上传到 S3 的目录（queries/）
const PREFIX = (process.env.QUERY_S3_PREFIX || 'queries/').replace(/^\/+|\/+$/g, '') + '/';
// 第三方返回结果文件所在的 S3 目录（download/）；可用 RESULT_S3_PREFIX 覆盖
const RESULT_PREFIX = (process.env.RESULT_S3_PREFIX || 'download/').replace(/^\/+|\/+$/g, '') + '/';

// YYYY-MM-DD -> YYYYMMDD（结果文件名日期段为紧凑格式，如 20240603）
function compactDate(d) {
  if (!d) return null;
  const m = String(d).match(/^(\d{4})-(\d{2})-(\d{2})$/);
  return m ? `${m[1]}${m[2]}${m[3]}` : null;
}

function dateStr(d = new Date()) {
  return d.toISOString().slice(0, 10);
}
function yesterdayStr() {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return d.toISOString().slice(0, 10);
}

function streamToBuffer(stream) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    stream.on('data', (c) => chunks.push(c));
    stream.on('end', () => resolve(Buffer.concat(chunks)));
    stream.on('error', reject);
  });
}

// 按"企业唯一标识"查找已存在的企业记录
// 标识规则：优先 (credit_code, insurance_type) 组合；回退到 credit_code 单独；再回退 name。
// 这能正确处理：同一企业不同险种=不同记录；不同企业=不同记录；同名企业靠 credit_code 区分。
export function findCompanyByConditions(c) {
  if (c.credit_code && c.insurance_type) {
    return get('SELECT * FROM companies WHERE credit_code=? AND insurance_type=?',
      [c.credit_code, c.insurance_type]);
  }
  if (c.credit_code) {
    return get('SELECT * FROM companies WHERE credit_code=?', [c.credit_code]);
  }
  if (c.name) {
    return get('SELECT * FROM companies WHERE name=?', [c.name]);
  }
  return null;
}

// 写入/更新企业记录，返回 id
function upsertCompany(c, resultData) {
  const existing = findCompanyByConditions(c);
  const rd = JSON.stringify(resultData || {});
  const now = new Date().toISOString();
  if (existing) {
    run('UPDATE companies SET result_data=?, last_query_time=? WHERE id=?', [rd, now, existing.id]);
    return existing.id;
  }
  return runReturnId(
    'INSERT INTO companies (query_type, name, credit_code, insurance_type, result_data, last_query_time, created_at) VALUES (?,?,?,?,?,?,?)',
    [c.query_type || '', c.name || '', c.credit_code || '', c.insurance_type || '', rd, now, now],
  );
}

// 按机构+条件匹配待查询记录
// 匹配规则：待查询记录中“用户实际填写”的字段，必须与结果行的对应字段逐一相等
// （结果文件可能补齐了待查询时留空的字段，因此不能做全字段精确匹配）
// org 为 null 时忽略机构限制（保留参数，便于将来扩展）
function findPending(org, c) {
  const candidates = all
    (org
      ? "SELECT * FROM pending_queries WHERE org=? AND status IN ('pending','exported')"
      : "SELECT * FROM pending_queries WHERE status IN ('pending','exported')",
      org ? [org] : []);
  const fields = ['query_type', 'name', 'credit_code', 'insurance_type'];
  for (const p of candidates) {
    let match = true;
    for (const f of fields) {
      const pv = (p[f] || '').trim();
      if (pv && (c[f] || '').trim() !== pv) { match = false; break; }
    }
    if (match) return p;
  }
  return null;
}

// 16:00：汇总未导出的待查询，按机构+日期生成文件上传 S3
export async function exportPending(date = dateStr()) {
  if (!BUCKET) throw new Error('S3_BUCKET 未配置，无法导出');
  const pending = all("SELECT * FROM pending_queries WHERE status='pending' ORDER BY org, id");
  if (!pending.length) return { files: [], skipped: true };

  const byOrg = {};
  for (const p of pending) (byOrg[p.org] ||= []).push(p);

  const files = [];
  for (const org of Object.keys(byOrg)) {
    const rows = byOrg[org].map((p) => ({
      query_type: p.query_type, name: p.name, credit_code: p.credit_code, insurance_type: p.insurance_type,
    }));
    const buf = await buildQueryExcel(rows);
    const key = `${PREFIX}${org}_${date}.xlsx`;
    await putObject(key, buf, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    const now = new Date().toISOString();
    for (const p of byOrg[org]) {
      run('UPDATE pending_queries SET status=?, exported_at=?, export_key=? WHERE id=?',
        ['exported', now, key, p.id]);
    }
    files.push({ org, key, count: rows.length });
  }
  persist();
  return { date, files };
}

// 解析并入库单个结果文件内容（独立于 S3，便于测试）
export async function processResultBuffer(org, buffer, sourceKey = 'test.xlsx') {
  const parsed = await parseResultExcel(buffer);
  let recordCount = 0;
  let pendingCount = 0;
  for (const item of parsed) {
    upsertCompany(item.conditions, item.resultData);
    recordCount++;
    const pend = findPending(org, item.conditions);
    if (pend) {
      run('UPDATE pending_queries SET status=?, result_file=?, result_at=? WHERE id=?',
        ['done', sourceKey, new Date().toISOString(), pend.id]);
      pendingCount++;
    }
  }
  persist();
  return { records: recordCount, pending: pendingCount };
}

// 检索 S3【download/】目录下“对应日期”的结果文件，下载第一个并解析入库
//  - 结果日期由前端传入（YYYY-MM-DD），转为紧凑格式 YYYYMMDD 后与文件名匹配
//  - 第三方返回命名：{机构}_{YYYYMMDD}{分公司名}_result.xlsx（如 A01_000001_20240603甘肃分公司_result.xlsx）
export async function importResults(date = yesterdayStr()) {
  if (!BUCKET) throw new Error('S3_BUCKET 未配置，无法导入');
  const compact = compactDate(date);
  if (!compact) throw new Error(`结果日期格式不正确：${date}（应为 YYYY-MM-DD）`);

  const { files } = await listObjects(RESULT_PREFIX);
  // 仅匹配：以 _result.xlsx 结尾，且文件名中含紧凑日期段 _YYYYMMDD
  const resultFiles = files
    .filter((f) => /_result\.xlsx$/i.test(f.name))
    .filter((f) => f.name.includes('_' + compact));
  if (!resultFiles.length) {
    const e = new Error(
      `在 S3【${RESULT_PREFIX}】目录下未找到 ${compact} 对应的结果文件（匹配 *_${compact}*_result.xlsx）`,
    );
    e.code = 'NO_RESULT';
    throw e;
  }
  // 仅下载并导入第一个匹配文件（用户要求：不下载全部）
  const first = resultFiles[0];
  const org = parseResultOrg(first.name);
  const obj = await getObject(first.key);
  let buf;
  if (obj.stream) buf = await streamToBuffer(obj.stream);
  else buf = Buffer.from(await obj.rawBody.transformToByteArray());

  const r = await processResultBuffer(org, buf, first.key);
  run('INSERT OR IGNORE INTO processed_results (key, processed_at, org, records, pending) VALUES (?,?,?,?,?)',
    [first.key, new Date().toISOString(), org, r.records, r.pending]);
  return { date, compactDate: compact, matched: resultFiles.length, imported: [{ key: first.key, org, ...r }], downloadedFirst: true };
}

// 从结果文件名解析机构代码（兼容 YYYYMMDD / YYYY-MM-DD 两种日期格式及中间的分公司名）
export function parseResultOrg(fileName) {
  const base = path.basename(fileName);
  const m = base.match(/^(.+?)_(\d{8}|\d{4}-\d{2}-\d{2})/);
  return m ? m[1] : 'UNKNOWN';
}

// 注意：原「每天 16:00 自动导出 / 次日 08:00 自动导入」的 cron 定时已移除。
// 现由管理员在前端「企业查询」页手动点击触发：
//   - 上传待查询 Excel 到 S3（queries/ 目录）：exportPending()
//   - 检索并导入返回的结果 Excel（download/ 目录，按日期 YYYYMMDD 匹配，仅下载第一个）：importResults()
// 这样既保留了“按机构+日期生成 queries/{机构}_{日期}.xlsx 并上传”的能力，
// 又避免了无人值守的自动调度。