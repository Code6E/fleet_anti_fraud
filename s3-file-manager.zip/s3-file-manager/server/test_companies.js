// 企业查询核心逻辑验证（不依赖真实 S3）
// 跑法：DB_PATH=/tmp/companies_test.db node test_companies.js
import { initDb, run, get, all } from './src/db.js';
import { buildQueryExcel, parseResultExcel } from './src/excel.js';
import { processResultBuffer, findCompanyByConditions } from './src/scheduler.js';
import ExcelJS from 'exceljs';

let pass = 0, fail = 0;
function check(name, cond) {
  if (cond) { pass++; console.log('  PASS', name); }
  else { fail++; console.log('  FAIL', name); }
}

async function main() {
  await initDb();

  // 1) 录入一条待查询（机构 ORG001）—— 按"名称"查
  run(
    `INSERT INTO pending_queries (org, requested_by, query_type, name, credit_code, insurance_type, status, created_at)
     VALUES (?,?,?,?,?,?,'pending',?)`,
    ['ORG001', 'u1', '被保险人', '山丹县万路通运输服务队', '92620725MA73D94DX8', '货物运输保险', new Date().toISOString()],
  );

  // 2) 构造结果 Excel（真实中银保信 18 列格式，文件名形如 ORG001_20240603甘肃分公司_result.xlsx）
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('result');
  ws.columns = [
    { header: '序号', key: 'serial', width: 6 },
    { header: '查询类别', key: 'qtype', width: 12 },
    { header: '名称', key: 'name', width: 28 },
    { header: '证件号码', key: 'credit', width: 22 },
    { header: '险种', key: 'itype', width: 16 },
    { header: '过去3年各年满期赔付率（已决）', key: 'lr1', width: 14 },
    { header: '过去3年各年满期赔付率（已决+未决）', key: 'lr2', width: 14 },
    { header: '近1年保费金额', key: 'prem', width: 12 },
    { header: '近1年单均保额、保费', key: 'avg', width: 14 },
    { header: '近1年起保当日出险保单数量及占比', key: 'd0', width: 12 },
    { header: '近1年起保2日内出险保单数量及占比', key: 'd2', width: 12 },
    { header: '近1年起保3日内出险保单数量及占比', key: 'd3', width: 12 },
    { header: '近1年出险原因及数量', key: 'cause', width: 20 },
    { header: '近1年保单最大保额', key: 'maxamt', width: 12 },
    { header: '最大保额保单对应保险期限', key: 'period', width: 12 },
    { header: '最大保额保单对应货物名称', key: 'cargo', width: 14 },
    { header: '最大保额保单对应起运地', key: 'from', width: 14 },
    { header: '最大保额保单对应目的地', key: 'to', width: 14 },
  ];
  ws.addRow({
    serial: 1, qtype: '被保险人', name: '山丹县万路通运输服务队', credit: '92620725MA73D94DX8', itype: '货物运输保险',
    lr1: 'Z,Z,Z', lr2: 'Z,Z,Z', prem: 0, avg: '0,0', d0: '0,0%', d2: '0,0%', d3: '0,0%',
    cause: 'A0,B0,C0', maxamt: null, period: null, cargo: null, from: null, to: null,
  });
  ws.addRow({
    serial: 1, qtype: '被保险人', name: '山丹县万路通运输服务队', credit: '92620725MA73D94DX8', itype: '物流责任保险',
    lr1: 'Z,Z,Z', lr2: 'Z,Z,Z', prem: 0, avg: '0,0', d0: '0,0%', d2: '0,0%', d3: '0,0%',
    cause: 'A0,B0,C0', maxamt: null, period: null, cargo: null, from: null, to: null,
  });
  ws.addRow({
    serial: 2, qtype: '被保险人', name: '江苏识律格商贸有限公司', credit: '91321391055232589A', itype: '货物运输保险',
    lr1: 'Z,Z,Z', lr2: 'Z,Z,Z', prem: 0, avg: '0,0', d0: '0,0%', d2: '0,0%', d3: '0,0%',
    cause: 'A0,B0,C0', maxamt: null, period: null, cargo: null, from: null, to: null,
  });
  const resultBuf = Buffer.from(await wb.xlsx.writeBuffer());

  // 3) 解析结果文件
  const parsed = await parseResultExcel(resultBuf);
  check('解析得到 3 行', parsed.length === 3);
  check('首行条件 name 命中', parsed[0].conditions.name === '山丹县万路通运输服务队');
  check('首行条件 credit_code 命中', parsed[0].conditions.credit_code === '92620725MA73D94DX8');
  check('首行条件 insurance_type 命中', parsed[0].conditions.insurance_type === '货物运输保险');
  check('resultData 携带完整 18 列', parsed[0].resultData['近1年保费金额'] === '0');

  // 4) 处理入库（应匹配到 ORG001 的待查询，并写入 3 条企业）
  const r = await processResultBuffer('ORG001', resultBuf, 'ORG001_20240603甘肃分公司_result.xlsx');
  check('入库企业数=3', r.records === 3);
  check('匹配待查询数=1', r.pending === 1);

  // 5) 校验 companies 表已写入且含 result_data / last_query_time
  const comp = get('SELECT * FROM companies WHERE name=? AND insurance_type=?',
    ['山丹县万路通运输服务队', '货物运输保险']);
  check('企业已入库', !!comp);
  check('result_data 含 18 列关键字段', comp && comp.result_data.includes('近1年保费金额'));
  check('last_query_time 已记录', comp && !!comp.last_query_time);

  // 6) 校验待查询状态变为 done
  const pend = get('SELECT * FROM pending_queries WHERE name=?', ['山丹县万路通运输服务队']);
  check('待查询状态=done', pend && pend.status === 'done');
  check('待查询关联结果文件', pend && pend.result_file === 'ORG001_20240603甘肃分公司_result.xlsx');

  // 7) findCompanyByConditions 可按任一字段命中
  check('按 credit_code 命中', !!findCompanyByConditions({ credit_code: '91321391055232589A' }));
  check('按 query_type+name 命中', !!findCompanyByConditions({ query_type: '被保险人', name: '江苏识律格商贸有限公司' }));
  check('陌生条件不命中', !findCompanyByConditions({ credit_code: '000000000000000000' }));

  // 8) buildQueryExcel 往返：用待查询行生成待查询文件并解析回来
  const pendingRows = all("SELECT * FROM pending_queries WHERE status='pending'");
  if (pendingRows.length) {
    const qBuf = await buildQueryExcel(pendingRows.map((p) => ({
      query_type: p.query_type, name: p.name, credit_code: p.credit_code, insurance_type: p.insurance_type,
    })));
    const qParsed = await parseResultExcel(qBuf);
    check('buildQueryExcel 行数正确', qParsed.length === pendingRows.length);
    check('buildQueryExcel 列头正确', qParsed[0].conditions.name === pendingRows[0].name);
  } else {
    console.log('  (无剩余 pending，跳过 buildQueryExcel 往返)');
  }

  console.log(`\n结果: ${pass} PASS / ${fail} FAIL`);
  process.exit(fail ? 1 : 0);
}

main().catch((e) => { console.error('测试异常:', e); process.exit(1); });