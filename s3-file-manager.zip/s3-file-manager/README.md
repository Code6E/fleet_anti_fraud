# S3 文件管理器

基于 S3 / 兼容存储的 Web 文件管理系统。后端 Express + AWS SDK v3，前端 React + Vite。

## 功能

- 文件/文件夹列表浏览（面包屑导航）
- 上传文件（支持多文件拖拽上传，单文件最大 500MB，分片上传）
- 下载文件
- 删除文件 / 删除文件夹（递归批量删除）
- 重命名文件 / 重命名文件夹（复制+删除）
- 新建文件夹
- 可选访问口令保护（设置 APP_PASSWORD 后前端需登录）
- **船舶查询系统**：按船舶识别号 / IMO号 / 中英文名任一项或多项查询，优先查本地记录；未命中可确认向中银保信发起查询，结果次日通过 S3 返回并入库
  - **手动触发上传**：在「船舶查询」页点击「上传待查询 Excel 到 S3」，按机构+日期汇总待查询文件上传
  - **手动触发导入**：次日结果返回后，在「船舶查询」页选择结果日期，点击「检索并导入返回结果 Excel」解析入库
  - ⚠️ 已移除自动定时任务（cron），所有上传/导入均需管理员手动触发，避免无人值守时误传/误读第三方结果

## 快速开始（一键启动）

Windows 用户双击 `start.bat` 即可：脚本会检查 `.env` 配置、自动构建前端、启动后端并打开浏览器。

> 首次运行需先安装依赖（见下方"手动安装"）。国内网络慢时建议用镜像：
> `npm install --registry=https://registry.npmmirror.com`

## 手动安装与配置

### 1. 配置 S3 连接

进入 `server/` 目录，复制 `.env.example` 为 `.env` 并填写：

```bash
cp .env.example .env
```

```ini
# AWS S3 留空；兼容存储(如 MinIO)填 http://127.0.0.1:9000
S3_ENDPOINT=http://your-s3-endpoint:port
S3_REGION=us-east-1
S3_BUCKET=your-bucket-name
S3_ACCESS_KEY_ID=your-access-key
S3_SECRET_ACCESS_KEY=your-secret-key
# MinIO 等兼容存储设为 true，AWS S3 设为 false
S3_FORCE_PATH_STYLE=true

PORT=3001

# ===== 登录与机构 =====
# 方式一（推荐，多用户+机构）：设置后启用“账号+口令”登录，每个用户归属一个机构(org)
# USERS=[{"username":"u1","password":"p1","org":"ORG001"},{"username":"u2","password":"p2","org":"ORG002"}]
USERS=
# 方式二（单口令）：仅设 APP_PASSWORD，机构取 DEFAULT_ORG
APP_PASSWORD=
DEFAULT_ORG=DEFAULT

# ===== 船舶查询：待查询/结果文件在 S3 上的目录前缀 =====
QUERY_S3_PREFIX=queries/
```

> ⚠️ **端口提示**：`PORT` 决定服务监听地址（如 `PORT=3001` → http://localhost:3001）。
> 若浏览器打不开该地址，请确认 `.env` 里的 `PORT` 与你访问的地址一致，并先停掉可能占用该端口的旧进程。

### 2. 安装依赖

```bash
# 后端
cd server
npm install

# 前端
cd ../web
npm install
```

### 3. 开发模式（前后端分离）

```bash
# 终端1：启动后端
cd server
npm start
# 后端运行在 http://localhost:3001

# 终端2：启动前端
cd web
npm run dev
# 前端运行在 http://localhost:3000（自动代理 /api 到后端）
```

打开 http://localhost:3000 即可使用。

### 4. 生产模式（后端托管前端）

```bash
# 先构建前端
cd web
npm run build

# 启动后端（自动检测 web/dist 并托管）
cd ../server
npm start
```

打开 http://localhost:3001 即可使用（前端+后端同一服务）。

## API 接口

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/health` | 健康检查 |
| GET | `/api/auth/required` | 是否需要口令 |
| POST | `/api/auth/login` | 口令登录 |
| GET | `/api/config` | S3 配置信息（不含密钥） |
| GET | `/api/files?prefix=` | 列出文件/文件夹 |
| GET | `/api/files/download?key=` | 下载文件 |
| POST | `/api/files/upload?prefix=` | 上传文件 |
| DELETE | `/api/files` | 删除文件/文件夹 |
| POST | `/api/files/rename` | 重命名 |
| POST | `/api/files/folder` | 新建文件夹 |
| GET | `/api/me` | 当前登录人信息与机构 |
| POST | `/api/ships/query` | 船舶本地查询（body 含 ship_id_no/imo_no/name_cn/name_en 中任一项或多项） |
| POST | `/api/ships/pending` | 确认向中银保信查询，录入待查询（自动记录当前登录机构与操作人） |
| GET | `/api/ships/pending` | 待查询队列列表（?status=pending/exported/done 可过滤） |
| GET | `/api/ships` | 本地船舶记录列表 |
| POST | `/api/ships/admin/export-now` | 手动触发：上传待查询 Excel 到 S3（`{前缀}{机构}_{日期}.xlsx`） |
| POST | `/api/ships/admin/import-now` | 手动触发：检索并导入返回结果 Excel（body 可传 `date`，默认取前一日） |

## 船舶查询系统

### 业务流
1. **本地查询**：按船舶识别号 / IMO号 / 船舶中文名称 / 船舶英文名称 中任一项或多项查询，优先查本地数据库；命中则返回记录及「上次查询时间」。
2. **未命中确认**：若本地无数据，前端提示可确认向中银保信发起查询，并明确「结果将于次日返回」。
   - 用户确认 → 将查询条件录入「待查询」，并记录**当前登录人所属机构**与操作人。
   - 用户取消 → 流程终止。
3. **手动上传待查询**：在「船舶查询」页点击「上传待查询 Excel 到 S3」，按「机构 + 日期」聚合待查询，生成 `queries/{机构}_{YYYY-MM-DD}.xlsx` 上传至 S3，并标记已导出。
4. **次日手动导入结果**：第三方返回结果后，在「船舶查询」页选择结果日期，点击「检索并导入返回结果 Excel」，检索 S3 上对应的结果文件 `queries/{机构}_{YYYY-MM-DD}result.xlsx`，下载并解析，将结果写入本地数据库（含完整返回字段与查询时间），并将对应待查询标记为「已完成」。

### Excel 格式约定
- **待查询文件** `queries/{机构}_{YYYY-MM-DD}.xlsx`，表头（顺序固定）：

  | 船舶识别号 | IMO号 | 船舶中文名称 | 船舶英文名称 |
  |---|---|---|---|

  每行一条待查询条件。

- **结果文件**：第三方（中银保信）在待查询文件同名后拼接 `result` 返回，即 `{机构}_{YYYY-MM-DD}result.xlsx`。
  除保留上述四列外，由第三方追加结果列（列名不固定，系统按「四列 + 其余列」解析，其余列全部存入 `result_data`）。

### 本地存储
- 数据使用 SQLite（`server/data/app.db`，基于 `sql.js` 纯 WASM 实现，无需原生编译），含三张表：
  - `ships`：本地船舶记录（四类标识 + `result_data` 原始返回 JSON + `last_query_time`）
  - `pending_queries`：待查询队列（含机构、操作人、状态、导出/结果文件关联）
  - `processed_results`：已处理结果文件去重记录

### 手动触发（主要使用方式，已无自动定时）
- 在「船舶查询」页顶部「手动触发」面板：
  - 点击 **上传待查询 Excel 到 S3** → 调用 `POST /api/ships/admin/export-now`；
  - 选择结果日期后点击 **检索并导入返回结果 Excel** → 调用 `POST /api/ships/admin/import-now`（body 可传 `{"date":"YYYY-MM-DD"}`，默认前一日）。
- 也可直接用接口/命令行触发：
  - `curl -X POST http://localhost:3001/api/ships/admin/export-now -H 'Content-Type: application/json' -d '{}'`
  - `curl -X POST http://localhost:3001/api/ships/admin/import-now -H 'Content-Type: application/json' -d '{"date":"2026-08-20"}'`
- 核心逻辑自测（不依赖 S3）：`DB_PATH=/tmp/test.db node server/test_ships.js`

> ⚠️ **S3 连通性**：手动触发会上传/下载真实 S3。若返回 `The specified bucket does not exist.`，请检查 `.env` 的 `S3_BUCKET` 桶名是否正确、凭证是否有该桶权限、以及 `S3_ENDPOINT`/`S3_FORCE_PATH_STYLE` 是否与你的兼容存储匹配。

## 技术栈

- 后端：Express 4 + @aws-sdk/client-s3 + multer 2 + sql.js（SQLite/WASM）+ exceljs
- 前端：React 18 + Vite 5
- 鉴权：可选 Bearer Token（多用户 USERS / 单口令 APP_PASSWORD）

## 目录结构

```
s3-file-manager/
  start.bat         Windows 一键启动脚本
  test_api.js       API 端到端测试
  test_ships.js     船舶查询核心逻辑测试（不依赖 S3）
  .gitignore
  README.md
  server/           后端
    data/           SQLite 数据库文件（运行时生成）
    src/
      index.js      入口，Express 应用
      s3.js         S3 操作封装
      db.js         SQLite 封装与表结构
      auth.js       登录与机构体系（多用户/单口令，可选）
      excel.js      Excel 读写（待查询/结果格式）
      scheduler.js  导出/导入函数（手动触发，无 cron 定时）
      routes/
        files.js    文件管理路由
        ships.js    船舶查询路由
    .env.example    配置模板
    package.json
  web/              前端
    src/
      main.jsx      入口
      App.jsx       主应用（登录 + 文件管理 + 船舶查询）
      api.js        API 封装与工具函数
      styles.css    样式
    index.html
    vite.config.js  Vite 配置（含 dev proxy）
    package.json
```
