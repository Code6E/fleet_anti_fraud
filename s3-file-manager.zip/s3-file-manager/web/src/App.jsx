import { useState, useEffect, useCallback, useRef } from 'react';
import {
  api, setToken, formatSize, formatDate, basename, parentPrefix,
} from './api.js';

// ====================== 登录页 ======================
function LoginPage({ onLogin }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const r = await api.login(username, password);
      if (r.status === 'ok') {
        setToken(r.token);
        onLogin(r);
      } else {
        setError(r.message || '登录失败');
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <form className="login-card" onSubmit={submit}>
        <div className="login-logo">S3</div>
        <h1>S3 文件管理器</h1>
        <p className="login-sub">请输入访问账号与口令</p>
        <input
          type="text"
          className="login-input"
          placeholder="账号"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          autoFocus
        />
        <input
          type="password"
          className="login-input"
          placeholder="访问口令"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        {error && <div className="login-error">{error}</div>}
        <button className="login-btn" disabled={loading || !password}>
          {loading ? '验证中...' : '进入'}
        </button>
      </form>
    </div>
  );
}

// ====================== 面包屑 ======================
function Breadcrumb({ prefix, onNavigate }) {
  const parts = prefix ? prefix.replace(/\/+$/, '').split('/') : [];
  const crumbs = [{ label: '根目录', prefix: '' }];
  let acc = '';
  for (const p of parts) {
    if (!p) continue;
    acc += p + '/';
    crumbs.push({ label: p, prefix: acc });
  }
  return (
    <div className="breadcrumb">
      {crumbs.map((c, i) => (
        <span key={i} className="crumb-wrap">
          {i > 0 && <span className="crumb-sep">/</span>}
          <span
            className={i === crumbs.length - 1 ? 'crumb current' : 'crumb'}
            onClick={() => onNavigate(c.prefix)}
          >
            {c.label}
          </span>
        </span>
      ))}
    </div>
  );
}

// ====================== 重命名对话框 ======================
function RenameDialog({ item, prefix, onClose, onDone }) {
  const [name, setName] = useState(item.name);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const submit = async () => {
    if (!name.trim() || name === item.name) { onClose(); return; }
    setLoading(true);
    setError('');
    try {
      const base = prefix || '';
      const from = item.key;
      const to = item.type === 'folder'
        ? (base + name.trim() + '/')
        : (base + name.trim());
      await api.rename(from, to, item.type);
      onDone();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="dialog-overlay" onClick={onClose}>
      <div className="dialog" onClick={(e) => e.stopPropagation()}>
        <h3>重命名 {item.type === 'folder' ? '文件夹' : '文件'}</h3>
        <input
          className="dialog-input"
          value={name}
          onChange={(e) => setName(e.target.value)}
          autoFocus
          onKeyDown={(e) => { if (e.key === 'Enter') submit(); }}
        />
        {error && <div className="dialog-error">{error}</div>}
        <div className="dialog-actions">
          <button className="btn btn-secondary" onClick={onClose}>取消</button>
          <button className="btn btn-primary" onClick={submit} disabled={loading}>
            {loading ? '处理中...' : '确认'}
          </button>
        </div>
      </div>
    </div>
  );
}

// ====================== 新建文件夹对话框 ======================
function NewFolderDialog({ prefix, onClose, onDone }) {
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const submit = async () => {
    if (!name.trim()) { onClose(); return; }
    setLoading(true);
    setError('');
    try {
      await api.createFolder(prefix, name.trim());
      onDone();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="dialog-overlay" onClick={onClose}>
      <div className="dialog" onClick={(e) => e.stopPropagation()}>
        <h3>新建文件夹</h3>
        <input
          className="dialog-input"
          placeholder="文件夹名称"
          value={name}
          onChange={(e) => setName(e.target.value)}
          autoFocus
          onKeyDown={(e) => { if (e.key === 'Enter') submit(); }}
        />
        {error && <div className="dialog-error">{error}</div>}
        <div className="dialog-actions">
          <button className="btn btn-secondary" onClick={onClose}>取消</button>
          <button className="btn btn-primary" onClick={submit} disabled={loading}>
            {loading ? '创建中...' : '创建'}
          </button>
        </div>
      </div>
    </div>
  );
}

// ====================== 确认删除对话框 ======================
function ConfirmDialog({ title, message, onClose, onConfirm, loading }) {
  return (
    <div className="dialog-overlay" onClick={onClose}>
      <div className="dialog" onClick={(e) => e.stopPropagation()}>
        <h3>{title}</h3>
        <p className="dialog-message">{message}</p>
        <div className="dialog-actions">
          <button className="btn btn-secondary" onClick={onClose}>取消</button>
          <button className="btn btn-danger" onClick={onConfirm} disabled={loading}>
            {loading ? '删除中...' : '删除'}
          </button>
        </div>
      </div>
    </div>
  );
}

// ====================== 文件列表行 ======================
function FileRow({ item, onNavigate, onDownload, onDelete, onRename }) {
  return (
    <tr className="file-row">
      <td className="col-icon">
        <span className={item.type === 'folder' ? 'icon folder-icon' : 'icon file-icon'}>
          {item.type === 'folder' ? '\u{1F4C1}' : '\u{1F4C4}'}
        </span>
        <span
          className={item.type === 'folder' ? 'file-name folder-name' : 'file-name'}
          onClick={() => item.type === 'folder' && onNavigate(item.key)}
        >
          {item.name}
        </span>
      </td>
      <td className="col-size">{item.type === 'file' ? formatSize(item.size) : '-'}</td>
      <td className="col-date">{item.type === 'file' ? formatDate(item.lastModified) : '-'}</td>
      <td className="col-actions">
        <button className="action-btn" title="下载" onClick={() => onDownload(item)}>下载</button>
        <button className="action-btn" title="重命名" onClick={() => onRename(item)}>重命名</button>
        <button className="action-btn danger" title="删除" onClick={() => onDelete(item)}>删除</button>
      </td>
    </tr>
  );
}

// ====================== 文件管理 ======================
function FileManager() {
  const [config, setConfig] = useState(null);
  const [prefix, setPrefix] = useState('');
  const [items, setItems] = useState({ folders: [], files: [] });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [uploading, setUploading] = useState(false);
  const [dragging, setDragging] = useState(false);
  const fileInputRef = useRef(null);
  const [renameTarget, setRenameTarget] = useState(null);
  const [newFolderOpen, setNewFolderOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const loadConfig = useCallback(async () => {
    try { setConfig(await api.getConfig()); } catch { /* ignore */ }
  }, []);

  const loadFiles = useCallback(async (p) => {
    setLoading(true);
    setError('');
    try {
      const data = await api.listFiles(p);
      setItems({ folders: data.folders || [], files: data.files || [] });
    } catch (err) {
      setError(err.message);
      setItems({ folders: [], files: [] });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadConfig(); loadFiles(prefix); }, []); // eslint-disable-line

  const navigate = useCallback((p) => { setPrefix(p); loadFiles(p); }, [loadFiles]);

  const handleUpload = async (files) => {
    if (!files || files.length === 0) return;
    setUploading(true);
    setError('');
    try {
      await api.upload(prefix, files);
      await loadFiles(prefix);
    } catch (err) {
      setError(err.message);
    } finally {
      setUploading(false);
    }
  };

  const onFileSelect = (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length) handleUpload(files);
    e.target.value = '';
  };

  const onDrop = (e) => {
    e.preventDefault();
    setDragging(false);
    const files = Array.from(e.dataTransfer.files || []);
    if (files.length) handleUpload(files);
  };

  const handleDownload = async (item) => {
    try {
      const res = await api.downloadUrl(item.key);
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = item.name;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } catch (err) {
      setError('下载失败: ' + err.message);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await api.remove(deleteTarget.key, deleteTarget.type);
      setDeleteTarget(null);
      await loadFiles(prefix);
    } catch (err) {
      setError(err.message);
    } finally {
      setDeleting(false);
    }
  };

  const allItems = [...items.folders, ...items.files];

  return (
    <div className="module">
      <div className="toolbar">
        <Breadcrumb prefix={prefix} onNavigate={navigate} />
        <div className="toolbar-actions">
          <button className="btn btn-primary btn-sm" onClick={() => fileInputRef.current?.click()} disabled={uploading}>
            {uploading ? '上传中...' : '上传文件'}
          </button>
          <input ref={fileInputRef} type="file" multiple style={{ display: 'none' }} onChange={onFileSelect} />
          <button className="btn btn-secondary btn-sm" onClick={() => setNewFolderOpen(true)}>新建文件夹</button>
          <button className="btn btn-secondary btn-sm" onClick={() => loadFiles(prefix)} disabled={loading}>刷新</button>
          {prefix && (
            <button className="btn btn-secondary btn-sm" onClick={() => navigate(parentPrefix(prefix))}>上级</button>
          )}
        </div>
      </div>

      {error && (
        <div className="error-bar">
          {error}
          <button className="error-close" onClick={() => setError('')}>x</button>
        </div>
      )}

      <div
        className="file-list-wrap"
        onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={onDrop}
      >
        {loading ? (
          <div className="empty-state">加载中...</div>
        ) : allItems.length === 0 ? (
          <div className="empty-state">
            {dragging ? '松开鼠标即可上传' : '此文件夹为空，上传文件或新建文件夹'}
          </div>
        ) : (
          <table className="file-table">
            <thead>
              <tr>
                <th className="col-icon">名称</th>
                <th className="col-size">大小</th>
                <th className="col-date">修改时间</th>
                <th className="col-actions">操作</th>
              </tr>
            </thead>
            <tbody>
              {allItems.map((item) => (
                <FileRow
                  key={item.key}
                  item={item}
                  onNavigate={navigate}
                  onDownload={handleDownload}
                  onDelete={setDeleteTarget}
                  onRename={setRenameTarget}
                />
              ))}
            </tbody>
          </table>
        )}
        {dragging && allItems.length > 0 && (
          <div className="drop-overlay">松开鼠标即可上传到当前文件夹</div>
        )}
      </div>

      {renameTarget && (
        <RenameDialog item={renameTarget} prefix={prefix}
          onClose={() => setRenameTarget(null)}
          onDone={() => { setRenameTarget(null); loadFiles(prefix); }} />
      )}
      {newFolderOpen && (
        <NewFolderDialog prefix={prefix}
          onClose={() => setNewFolderOpen(false)}
          onDone={() => { setNewFolderOpen(false); loadFiles(prefix); }} />
      )}
      {deleteTarget && (
        <ConfirmDialog title="确认删除"
          message={`确定要删除${deleteTarget.type === 'folder' ? '文件夹' : '文件'} "${deleteTarget.name}" 吗？${deleteTarget.type === 'folder' ? '该操作将删除文件夹下的所有内容。' : '此操作不可恢复。'}`}
          loading={deleting}
          onClose={() => setDeleteTarget(null)}
          onConfirm={handleDelete} />
      )}
    </div>
  );
}

// ====================== 企业查询（货运险/物流责任险） ======================
function CompanyQuery({ me }) {
  const [form, setForm] = useState({ query_type: '', name: '', credit_code: '', insurance_type: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [result, setResult] = useState(null); // {found, results, message, conditions}
  const [confirming, setConfirming] = useState(false);
  const [pendingList, setPendingList] = useState([]);
  const [companies, setCompanies] = useState([]);
  const [toast, setToast] = useState('');
  const [opLoading, setOpLoading] = useState(false);
  const [opMsg, setOpMsg] = useState('');
  const [resultDate, setResultDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() - 1);
    return d.toISOString().slice(0, 10);
  });

  const emptyForm = { query_type: '', name: '', credit_code: '', insurance_type: '' };

  const loadSide = useCallback(async () => {
    try {
      const [p, c] = await Promise.all([api.listPending(), api.listCompanies()]);
      setPendingList(p.rows || []);
      setCompanies(c.rows || []);
    } catch (err) {
      setError(err.message);
    }
  }, []);

  useEffect(() => { loadSide(); }, [loadSide]);

  const update = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const doQuery = async () => {
    setError(''); setResult(null); setConfirming(false);
    const f = { ...form };
    if (!f.query_type && !f.name && !f.credit_code && !f.insurance_type) {
      setError('请至少填写一项查询条件');
      return;
    }
    setLoading(true);
    try {
      const r = await api.companyQuery(f);
      setResult(r);
      if (r.found) setConfirming(false);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const confirmQuery = async () => {
    setLoading(true);
    try {
      const c = result.conditions || form;
      const r = await api.companyPending(c);
      setToast((r.message || '已提交') + (r.org ? `（机构：${r.org}）` : ''));
      setResult(null);
      setForm(emptyForm);
      await loadSide();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const statusLabel = (s) => ({ pending: '待导出', exported: '已上传', done: '已完成' }[s] || s);

  const runExport = async () => {
    setOpLoading(true); setOpMsg(''); setError('');
    try {
      const r = await api.exportNow();
      if (r.files && r.files.length) {
        setOpMsg(`已上传 ${r.files.length} 个待查询文件：` + r.files.map((f) => `${f.org}(${f.count}条)`).join('、'));
      } else {
        setOpMsg(r.skipped ? '当前没有待导出的待查询记录（队列为空）' : '已处理，但未生成文件');
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setOpLoading(false);
    }
  };

  const runImport = async () => {
    setOpLoading(true); setOpMsg(''); setError('');
    try {
      const r = await api.importNow({ date: resultDate });
      if (r.imported && r.imported.length) {
        const totalRecords = r.imported.reduce((a, b) => a + (b.records || 0), 0);
        const totalPending = r.imported.reduce((a, b) => a + (b.pending || 0), 0);
        setOpMsg(`在 S3【download/】目录匹配到 ${r.matched || 1} 个结果文件（*_${r.compactDate}*_result.xlsx），已下载并导入第 1 个：入库企业 ${totalRecords} 条，匹配待查询 ${totalPending} 条`);
        await loadSide();
      } else {
        setOpMsg(r.message || `在 S3【download/】目录下未找到 ${resultDate} 对应的结果文件`);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setOpLoading(false);
    }
  };

  return (
    <div className="module">
      {toast && <div className="toast-bar" onClick={() => setToast('')}>{toast} ✓</div>}
      {error && <div className="error-bar">{error}<button className="error-close" onClick={() => setError('')}>x</button></div>}

      <div className="panel">
        <h3 className="panel-title">企业查询</h3>
        <p className="panel-hint">
          可按 <b>查询类别 / 名称 / 证件号码 / 险种</b> 中的任一项或多项查询（提供的字段间为 AND）。
          优先查询本地记录；未命中时可确认向中银保信发起查询，结果将于次日返回。
          当前机构：<b>{me?.org || 'DEFAULT'}</b>
        </p>
        <div className="ship-form">
          <label>查询类别
            <input list="opt-query-type" value={form.query_type} onChange={(e) => update('query_type', e.target.value)} placeholder="投保人 / 被保险人" />
          </label>
          <datalist id="opt-query-type">
            <option value="投保人" />
            <option value="被保险人" />
          </datalist>
          <label>名称（公司名）
            <input value={form.name} onChange={(e) => update('name', e.target.value)} placeholder="如：上海锦陈物流有限公司" />
          </label>
          <label>证件号码（统一社会信用代码）
            <input value={form.credit_code} onChange={(e) => update('credit_code', e.target.value)} placeholder="如：913101185727027881" />
          </label>
          <label>险种
            <input list="opt-insurance-type" value={form.insurance_type} onChange={(e) => update('insurance_type', e.target.value)} placeholder="货物运输保险 / 物流责任保险" />
          </label>
          <datalist id="opt-insurance-type">
            <option value="货物运输保险" />
            <option value="物流责任保险" />
          </datalist>
        </div>
        <div className="toolbar-actions">
          <button className="btn btn-primary btn-sm" onClick={doQuery} disabled={loading}>查询</button>
          <button className="btn btn-secondary btn-sm" onClick={() => { setForm(emptyForm); setResult(null); }}>清空</button>
        </div>
      </div>

      <div className="panel">
        <h3 className="panel-title">手动触发（上传 / 检索导入）</h3>
        <p className="panel-hint">
          待查询文件不再自动定时上传；待查询条件录入后，请在此手动上传至 S3（queries/ 目录）。
          第三方于次日返回结果文件（命名如 <code>{'{机构}'}_{'{YYYYMMDD}'}{'{分公司名}'}_result.xlsx</code>，内含企业 + 险种 + 赔付率等 18 列）后，
          在此选择结果日期（将自动转为 YYYYMMDD 格式），从 S3 的 <code>download/</code> 目录匹配并导入。
        </p>
        <div className="toolbar-actions">
          <button className="btn btn-primary btn-sm" onClick={runExport} disabled={opLoading}>上传待查询 Excel 到 S3</button>
          <span className="date-label">结果日期</span>
          <input type="date" className="date-input" value={resultDate} onChange={(e) => setResultDate(e.target.value)} />
          <button className="btn btn-secondary btn-sm" onClick={runImport} disabled={opLoading}>检索并导入返回结果 Excel</button>
        </div>
        {opMsg && <div className="toast-bar" onClick={() => setOpMsg('')}>{opMsg} ✓</div>}
      </div>

      {result && result.found && (
        <div className="panel">
          <h3 className="panel-title">本地命中记录（共 {result.results.length} 条）</h3>
          <table className="file-table">
            <thead>
              <tr>
                <th>查询类别</th><th>名称</th><th>证件号码</th><th>险种</th><th>上次查询时间</th>
              </tr>
            </thead>
            <tbody>
              {result.results.map((r) => (
                <tr key={r.id} className="file-row">
                  <td>{r.query_type || '-'}</td>
                  <td>{r.name || '-'}</td>
                  <td>{r.credit_code || '-'}</td>
                  <td>{r.insurance_type || '-'}</td>
                  <td>{r.last_query_time ? formatDate(r.last_query_time) : '无'}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <p className="panel-hint">以上为本地已有数据，无需向中银保信发起查询。</p>
        </div>
      )}

      {result && !result.found && (
        <div className="panel">
          <p className="panel-hint">{result.message}</p>
          {!confirming ? (
            <div className="toolbar-actions">
              <button className="btn btn-primary btn-sm" onClick={() => setConfirming(true)}>确认向中银保信发起查询</button>
              <button className="btn btn-secondary btn-sm" onClick={() => setResult(null)}>取消</button>
            </div>
          ) : (
            <div className="confirm-box">
              <p>确认将以下查询条件提交至待查询队列？提交后进入待查询队列，由管理员手动触发上传至 S3；第三方结果将于次日返回，再由管理员手动检索导入。</p>
              <ul className="cond-list">
                {result.conditions.query_type && <li>查询类别：{result.conditions.query_type}</li>}
                {result.conditions.name && <li>名称：{result.conditions.name}</li>}
                {result.conditions.credit_code && <li>证件号码：{result.conditions.credit_code}</li>}
                {result.conditions.insurance_type && <li>险种：{result.conditions.insurance_type}</li>}
              </ul>
              <div className="toolbar-actions">
                <button className="btn btn-primary btn-sm" onClick={confirmQuery} disabled={loading}>提交查询</button>
                <button className="btn btn-secondary btn-sm" onClick={() => setConfirming(false)}>再想想</button>
              </div>
            </div>
          )}
        </div>
      )}

      <div className="panel">
        <h3 className="panel-title">待查询队列</h3>
        <table className="file-table">
          <thead>
            <tr><th>机构</th><th>操作人</th><th>查询类别</th><th>名称</th><th>证件号码</th><th>险种</th><th>状态</th><th>创建时间</th></tr>
          </thead>
          <tbody>
            {pendingList.length === 0 && <tr><td colSpan="8" className="empty-state">暂无待查询记录</td></tr>}
            {pendingList.map((p) => (
              <tr key={p.id} className="file-row">
                <td>{p.org}</td>
                <td>{p.requested_by}</td>
                <td>{p.query_type || '-'}</td>
                <td>{p.name || '-'}</td>
                <td>{p.credit_code || '-'}</td>
                <td>{p.insurance_type || '-'}</td>
                <td>{statusLabel(p.status)}</td>
                <td>{p.created_at ? formatDate(p.created_at) : '-'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="panel">
        <h3 className="panel-title">本地企业数据（最近 {companies.length} 条）</h3>
        <table className="file-table">
          <thead>
            <tr><th>查询类别</th><th>名称</th><th>证件号码</th><th>险种</th><th>上次查询时间</th></tr>
          </thead>
          <tbody>
            {companies.length === 0 && <tr><td colSpan="5" className="empty-state">暂无本地数据</td></tr>}
            {companies.map((r) => (
              <tr key={r.id} className="file-row">
                <td>{r.query_type || '-'}</td>
                <td>{r.name || '-'}</td>
                <td>{r.credit_code || '-'}</td>
                <td>{r.insurance_type || '-'}</td>
                <td>{r.last_query_time ? formatDate(r.last_query_time) : '无'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ====================== 顶层 App ======================
export default function App() {
  const [authed, setAuthed] = useState(false);
  const [checkingAuth, setCheckingAuth] = useState(true);
  const [needsAuth, setNeedsAuth] = useState(false);
  const [me, setMe] = useState(null);
  const [view, setView] = useState('files'); // files | companies

  useEffect(() => {
    (async () => {
      try {
        const required = await api.authRequired();
        if (!required) {
          setNeedsAuth(false);
          setAuthed(true);
        } else if (localStorage.getItem('s3fm_token')) {
          try {
            const m = await api.me();
            setMe(m);
            setNeedsAuth(true);
            setAuthed(true);
          } catch {
            setNeedsAuth(true);
            setAuthed(false);
          }
        } else {
          setNeedsAuth(true);
          setAuthed(false);
        }
      } catch {
        setNeedsAuth(false);
        setAuthed(true);
      } finally {
        setCheckingAuth(false);
      }
    })();
  }, []);

  const onLogin = async (loginRes) => {
    try {
      const m = await api.me();
      setMe(m);
    } catch {
      setMe({ username: loginRes?.username, org: loginRes?.org });
    }
    setAuthed(true);
  };

  if (checkingAuth) return <div className="loading-screen">正在初始化...</div>;
  if (needsAuth && !authed) return <LoginPage onLogin={onLogin} />;

  return (
    <div className="app">
      <header className="topbar">
        <div className="topbar-left">
          <span className="logo">S3</span>
          <span className="title">文件管理器</span>
          <nav className="nav">
            <button className={view === 'files' ? 'nav-btn active' : 'nav-btn'} onClick={() => setView('files')}>文件管理</button>
            <button className={view === 'companies' ? 'nav-btn active' : 'nav-btn'} onClick={() => setView('companies')}>企业查询</button>
          </nav>
        </div>
        <div className="topbar-right">
          {me && (
            <span className="bucket-info">
              {me.username} · 机构 {me.org}
            </span>
          )}
          {needsAuth && (
            <button className="btn btn-secondary btn-sm" onClick={() => { setToken(''); setAuthed(false); }}>
              退出
            </button>
          )}
        </div>
      </header>

      {view === 'files' ? <FileManager /> : <CompanyQuery me={me} />}
    </div>
  );
}

function getTokenFromStorage() {
  return localStorage.getItem('s3fm_token') || '';
}
