// ---- token 管理 ----
let token = localStorage.getItem('s3fm_token') || '';

export function setToken(t) {
  token = t || '';
  if (token) localStorage.setItem('s3fm_token', token);
  else localStorage.removeItem('s3fm_token');
}

export function getToken() {
  return token;
}

// ---- 通用 fetch 封装 ----
async function request(url, options = {}) {
  const headers = { ...options.headers };
  if (token) headers['Authorization'] = 'Bearer ' + token;

  const res = await fetch(url, {
    ...options,
    headers,
  });

  const ct = res.headers.get('content-type') || '';
  if (ct.includes('application/json')) {
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || `HTTP ${res.status}`);
    return data;
  }
  // 非JSON（如文件下载流）
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res;
}

// ---- API ----
export const api = {
  health: () => request('/api/health').then((d) => d.status === 'ok'),

  authRequired: () =>
    request('/api/auth/required').then((d) => d.required),

  login: (username, password) =>
    request('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    }),

  getConfig: () => request('/api/config'),

  listFiles: (prefix = '') =>
    request('/api/files?prefix=' + encodeURIComponent(prefix)),

  downloadUrl: (key) => {
    const h = token ? { Authorization: 'Bearer ' + token } : {};
    // 下载用 fetch 流处理（带 auth header）
    return request('/api/files/download?key=' + encodeURIComponent(key), { headers: h });
  },

  upload: (prefix, files) => {
    const fd = new FormData();
    for (const f of files) fd.append('files', f);
    return request('/api/files/upload?prefix=' + encodeURIComponent(prefix), {
      method: 'POST',
      body: fd,
    });
  },

  remove: (key, type) =>
    request('/api/files', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key, type }),
    }),

  rename: (from, to, type) =>
    request('/api/files/rename', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ from, to, type }),
    }),

  createFolder: (prefix, name) =>
    request('/api/files/folder', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prefix, name }),
    }),

  // ---- 当前登录人 / 机构 ----
  me: () => request('/api/me'),

  // ---- 企业查询（货运险/物流责任险维度） ----
  companyQuery: (cond) =>
    request('/api/companies/query', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(cond),
    }),

  companyPending: (cond) =>
    request('/api/companies/pending', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(cond),
    }),

  listPending: (status) =>
    request('/api/companies/pending' + (status ? `?status=${encodeURIComponent(status)}` : '')),

  listCompanies: () => request('/api/companies'),

  exportNow: () =>
    request('/api/companies/admin/export-now', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: '{}',
    }),

  importNow: (params = {}) =>
    request('/api/companies/admin/import-now', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    }),
};

// ---- 工具 ----
export function formatSize(bytes) {
  if (!bytes || bytes === 0) return '-';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let i = 0;
  let n = bytes;
  while (n >= 1024 && i < units.length - 1) { n /= 1024; i++; }
  return n.toFixed(i === 0 ? 0 : 1) + ' ' + units[i];
}

export function formatDate(iso) {
  if (!iso) return '-';
  const d = new Date(iso);
  return d.toLocaleString('zh-CN', {
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit',
  });
}

export function basename(key) {
  if (!key) return '';
  return key.replace(/\/+$/, '').split('/').pop();
}

export function parentPrefix(prefix) {
  if (!prefix) return '';
  const p = prefix.replace(/\/+$/, '');
  const idx = p.lastIndexOf('/');
  if (idx < 0) return '';
  return p.slice(0, idx + 1);
}
