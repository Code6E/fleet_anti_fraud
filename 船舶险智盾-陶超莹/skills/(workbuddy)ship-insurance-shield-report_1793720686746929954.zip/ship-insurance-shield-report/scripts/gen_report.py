# -*- coding: utf-8 -*-
"""
船舶险智盾解读报告生成脚本 (ship-insurance-shield-report)
==========================================================
读取船舶险反欺诈查询数据 (xlsx)，按船名定位该船记录，
套用《风险评估维度》规则分别判定「业务品质」「欺诈风险」等级，
结合《指标解读》口径生成六段式智盾解读报告 (docx)。

用法示例：
  python gen_report.py --query 船舶险反欺诈案例.xlsx --ship 万国顺达 \
      --gt 17167 --type 散货船
"""
import argparse
import os
import sys
import time
import datetime

from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement, parse_xml
import openpyxl

# ---------------- 颜色定义 ----------------
GREEN = RGBColor(0x2E, 0x7D, 0x32)   # 低风险-绿
YELLOW = RGBColor(0xB8, 0x86, 0x0B)  # 中风险-黄
RED = RGBColor(0xC0, 0x00, 0x00)     # 高风险-红
GRAY = RGBColor(0x80, 0x80, 0x80)
BLUE = RGBColor(0x1F, 0x4E, 0x79)

LEVEL = {
    'high': ('高风险', RED),
    'medium': ('中风险', YELLOW),
    'low': ('低风险', GREEN),
}
YEAR_LABELS = ['2026年(当年)', '2025年', '2024年', '2023年']

# 默认水印文本（斜向展示）
DEFAULT_WATERMARK = '总公司/1010000789'


def skill_assets():
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(here, '..', 'assets')


# ============================================================
#  数据解析工具
# ============================================================
def to_float_list(s, n=4):
    """把 '0,0,16,0' / (null) / Z 解析为 [当年,上一年,前年,大前年] 浮点列表。"""
    if s is None:
        return [None] * n
    s = str(s).strip()
    if s in ('(null)', 'Z', ''):
        return [None] * n
    out = []
    for p in s.split(','):
        p = p.strip()
        try:
            out.append(float(p))
        except ValueError:
            out.append(None)
    while len(out) < n:
        out.append(None)
    return out[:n]


def parse_claim_count(s):
    """出险原因 '意外事故类|2' 或 '其他|1,触碰|1' -> 合计次数。"""
    if s is None:
        return 0
    s = str(s).strip()
    if s == '(null)':
        return 0
    total = 0
    for grp in s.split(','):
        if '|' in grp:
            try:
                total += int(float(grp.split('|')[-1].strip()))
            except ValueError:
                pass
    return total


def parse_reasons(s):
    """出险原因 '意外事故类|2' -> [('意外事故类',2)]。"""
    if not s or str(s).strip() == '(null)':
        return []
    out = []
    for grp in str(s).split(','):
        if '|' in grp:
            rsn, cnt = grp.split('|', 1)
            try:
                out.append((rsn.strip(), int(float(cnt.strip()))))
            except ValueError:
                out.append((rsn.strip(), 0))
    return out


def parse_amount(s):
    if s is None:
        return 0
    s = str(s).strip()
    if s == '(null)':
        return 0
    try:
        return float(s)
    except ValueError:
        return 0


def fmt_money(yuan):
    wan = yuan / 10000.0
    if wan >= 10000:
        return f"{wan/10000:.2f}亿元"
    return f"{wan:.0f}万元"


# ============================================================
#  读取查询文件、定位船名、构建记录
# ============================================================
def _find_col(header, include, exclude=None):
    for i, h in enumerate(header):
        if h is None:
            continue
        t = str(h).replace('\n', '').replace(' ', '')
        inc = all(k.replace(' ', '') in t for k in include)
        exc = exclude is not None and any(e.replace(' ', '') in t for e in exclude)
        if inc and not exc:
            return i
    return None


def locate_columns(header):
    cols = {}
    cols['ship'] = _find_col(header, ['船舶中文名'])
    cols['id'] = _find_col(header, ['船舶识别号'])
    cols['imo'] = _find_col(header, ['IMO'])
    cols['kind'] = _find_col(header, ['险种小类'])
    cols['settled'] = _find_col(header, ['满期赔付率', '已决'], exclude=['未决'])
    cols['adj_unpd'] = _find_col(header, ['满期赔付率', '已决', '未决'])
    cols['claim'] = _find_col(header, ['出险原因及数量'])
    cols['amount'] = _find_col(header, ['赔案金额'])
    cols['m0'] = _find_col(header, ['起保当月'])
    cols['m2'] = _find_col(header, ['起保2个月'])
    cols['m3'] = _find_col(header, ['起保3个月'])
    cols['ins_count'] = _find_col(header, ['保险公司数量'])
    cols['ins_code'] = _find_col(header, ['保险公司代码'])
    cols['avg_sum'] = _find_col(header, ['单均保额'])
    cols['avg_prem'] = _find_col(header, ['单均保费'])
    return cols


def load_records(query_path, ship):
    wb = openpyxl.load_workbook(query_path, read_only=True, data_only=True)
    if '案例及字段' in wb.sheetnames:
        ws = wb['案例及字段']
    else:
        ws = wb.worksheets[0]
    rows = list(ws.iter_rows(values_only=True))
    wb.close()
    if not rows:
        raise SystemExit("查询文件为空")
    header = rows[0]
    cols = locate_columns(header)
    required = ['ship', 'kind', 'settled', 'adj_unpd', 'm0', 'm2', 'm3',
                'ins_count', 'ins_code', 'avg_sum', 'avg_prem']
    missing = [k for k in required if cols.get(k) is None
               or (k == 'claim' and cols.get('claim') is None)
               or (k == 'amount' and cols.get('amount') is None)]
    # claim/amount 允许缺失（部分船无出险）
    missing = [k for k in ('ship', 'kind', 'settled', 'adj_unpd', 'm0', 'm2', 'm3',
               'ins_count', 'ins_code', 'avg_sum', 'avg_prem') if cols.get(k) is None]
    if missing:
        raise SystemExit("查询文件缺少必要列：%s\n实际表头：%s" % (missing, header))

    matched = []
    for row in rows[1:]:
        name = row[cols['ship']]
        if name is None:
            continue
        if str(name).strip() == ship:
            matched.append(row)
    if not matched:
        for row in rows[1:]:
            name = row[cols['ship']]
            if name and ship in str(name):
                matched.append(row)
    if not matched:
        avail = sorted({str(r[cols['ship']]).strip() for r in rows[1:]
                        if r[cols['ship']] is not None})
        raise SystemExit("未在查询文件中找到船名 %r。可用的船名：%s" % (ship, avail))

    records = []
    for row in matched:
        def g(k):
            idx = cols.get(k)
            return row[idx] if idx is not None else None
        rec = {
            'kind': g('kind'),
            'settled': to_float_list(g('settled')),
            'adj_unpd': to_float_list(g('adj_unpd')),
            'claim_raw': g('claim'),
            'claim_count': parse_claim_count(g('claim')),
            'claim_amount': parse_amount(g('amount')),
            'm0': (str(g('m0')).strip() if g('m0') is not None else ''),
            'm2': (str(g('m2')).strip() if g('m2') is not None else ''),
            'm3': (str(g('m3')).strip() if g('m3') is not None else ''),
            'ins_count': (int(g('ins_count')) if g('ins_count') is not None else None),
            'ins_code': (str(g('ins_code')).strip() if g('ins_code') is not None else ''),
            'avg_sum': parse_amount(g('avg_sum')),
            'avg_prem': parse_amount(g('avg_prem')),
            'ship_id': g('id'),
            'imo': g('imo'),
        }
        records.append(rec)
    return records


# ============================================================
#  风险评估规则（依据《风险评估维度.xlsx》）
# ============================================================
def judge_business(records):
    """返回 'high' / 'medium' / 'low'。"""
    # 高风险
    r2 = any((r['adj_unpd'][0] or 0) > 500 or (r['adj_unpd'][1] or 0) > 500
             for r in records)
    r3 = any(r['claim_count'] > 3 for r in records)
    r1 = (len(records) >= 3 and
          any((v or 0) > 100 for r in records for v in r['adj_unpd']))
    if r1 or r2 or r3:
        return 'high'
    # 低风险：所有险种已决+未决均<55 且 出险合计<=1 且 赔案合计<10万
    all_low = all((v or 0) < 55 for r in records for v in r['adj_unpd'])
    total_claim = sum(r['claim_count'] for r in records)
    total_amt = sum(r['claim_amount'] for r in records)
    if all_low and total_claim <= 1 and total_amt < 100000:
        return 'low'
    return 'medium'


def judge_fraud(records):
    """返回 'high' / 'medium' / 'low'。"""
    m0 = records[0]['m0']
    m2 = records[0]['m2']
    m3 = records[0]['m3']
    z = '0,0.00%'
    if m0 != z:
        return 'high'
    if m0 == m2 == m3 == z:
        return 'low'
    return 'medium'


def build_org_map(org_path, limit=20000):
    """机构代码 -> 机构名称。"""
    wb = openpyxl.load_workbook(org_path, read_only=True, data_only=True)
    ws = wb['保险机构代码']
    m = {}
    for row in ws.iter_rows(values_only=True, max_row=limit):
        code, name = row[0], row[1] if len(row) > 1 else None
        if code is None or name is None:
            continue
        m[str(code).strip()] = str(name).strip()
    wb.close()
    return m


# ============================================================
#  DOCX 生成
# ============================================================
def add_run(p, text, size=11, bold=False, color=None, font='宋体'):
    r = p.add_run(text)
    r.font.name = font
    rpr = r._element.get_or_add_rPr()
    rpr.rFonts.set(qn('w:eastAsia'), font)
    if size:
        r.font.size = Pt(size)
    r.bold = bold
    if color:
        r.font.color.rgb = color
    return r


def add_para(doc, text, size=11, bold=False, color=None, font='宋体',
             align=None, space_after=4):
    p = doc.add_paragraph()
    if align:
        p.alignment = align
    p.paragraph_format.space_after = Pt(space_after)
    return add_run(p, text, size, bold, color, font)


def add_heading(doc, text, level=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(4)
    if level == 1:
        add_run(p, text, size=15, bold=True, color=BLUE, font='黑体')
        pPr = p._p.get_or_add_pPr()
        pbdr = OxmlElement('w:pBdr')
        bottom = OxmlElement('w:bottom')
        bottom.set(qn('w:val'), 'single')
        bottom.set(qn('w:sz'), '8')
        bottom.set(qn('w:space'), '4')
        bottom.set(qn('w:color'), '1F4E79')
        pbdr.append(bottom)
        pPr.append(pbdr)
    else:
        add_run(p, text, size=12, bold=True, font='黑体')
    return p


def add_bullet(doc, text, size=11):
    p = doc.add_paragraph(style='List Number')
    p.paragraph_format.space_after = Pt(2)
    return add_run(p, text, size)


def add_label_color(doc, label, level_key):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(2)
    add_run(p, label, bold=True)
    txt, col = LEVEL[level_key]
    add_run(p, txt, bold=True, color=col)
    return p


def add_slant_watermark(doc, text):
    """斜向（约 -51°）VML 水印。"""
    header = doc.sections[0].header
    hp = header.paragraphs[0]
    pict_xml = (
        '<w:pict xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
        'xmlns:v="urn:schemas-microsoft-com:vml" '
        'xmlns:o="urn:schemas-microsoft-com:office:office" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        '<v:shapetype id="_wms" coordsize="21600,21600" o:spt="202" path="m,l,21600,21600,21600,21600,0,21600,0,0,21600,0,21600,0,0,0,0 e">'
        '<v:stroke joinstyle="miter"/><v:path gradientshapeok="t" o:connecttype="rect"/>'
        '<o:lock v:ext="edit" aspectratio="t"/></v:shapetype>'
        '<v:shape id="_wm1" type="#_wms" style="position:absolute;margin-left:-30pt;margin-top:150pt;'
        'width:540pt;height:70pt;rotation:-3060000;'
        'z-index:-251657216;visibility:visible;mso-wrap-edited:0;mso-position-horizontal:center;'
        'mso-position-horizontal-relative:page;mso-position-vertical:center;'
        'mso-position-vertical-relative:page" fillcolor="white" stroked="f">'
        '<v:textbox style="mso-fit-shape-to-text:t" inset="0pt,0pt,0pt,0pt">'
        '<w:txbxContent><w:p><w:pPr><w:jc w:val="center"/></w:pPr>'
        '<w:r><w:rPr><w:rFonts w:ascii="Microsoft YaHei" w:hAnsi="Microsoft YaHei" w:eastAsia="Microsoft YaHei"/>'
        '<w:color w:val="CCCCCC"/><w:sz w:val="44"/><w:szCs w:val="44"/></w:rPr>'
        '<w:t xml:space="preserve">' + text + '</w:t></w:r></w:p></w:txbxContent>'
        '</v:textbox></v:shape></w:pict>'
    )
    hp._p.append(parse_xml(pict_xml))


def generate(args, records, org_map):
    doc = Document()
    normal = doc.styles['Normal']
    normal.font.name = '宋体'
    normal.font.size = Pt(11)
    normal.element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')

    ship = args.ship

    # ---------- 封面 ----------
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    add_run(title, f'“{ship}”智盾解读报告', size=22, bold=True, color=BLUE, font='黑体')
    title.paragraph_format.space_after = Pt(2)
    sub = doc.add_paragraph()
    sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    add_run(sub, '船舶险反欺诈风控服务 · AI 数据解读', size=11, color=GRAY)
    sub.paragraph_format.space_after = Pt(10)

    # ---------- 一、船舶档案 ----------
    add_heading(doc, '一、船舶档案')
    add_para(doc, f'船舶名称：{ship}')
    sid = args.id or (records[0]['ship_id'] if records[0]['ship_id'] else None)
    if sid:
        add_para(doc, f'船舶识别号：{sid}')
    if args.type:
        add_para(doc, f'船舶类型：{args.type}')
    if args.gt:
        add_para(doc, f'总吨位（GT）：{args.gt:g}')
    imo = args.imo or records[0]['imo']
    if imo:
        add_para(doc, f'IMO号：{imo}')

    # ---------- 二、业务品质分析 ----------
    add_heading(doc, '二、业务品质分析')
    kinds = [r['kind'] for r in records if r['kind']]
    add_para(doc, '过往3年投保的险种分别为：' + '、'.join(kinds) + '。')
    for r in records:
        add_para(doc, f"{r['kind']}：", bold=True)
        settled = r['settled']
        if all((v or 0) == 0 for v in settled):
            add_para(doc, '统计区间内已决满期赔付率各年度均为 0；')
        else:
            parts = [f"{lbl}为 {v:.0f}%" for lbl, v in zip(YEAR_LABELS, settled) if v]
            add_para(doc, '已决满期赔付率：' + '，'.join(parts) + '；')
        unpd = r['adj_unpd']
        nz = [(lbl, v) for lbl, v in zip(YEAR_LABELS, unpd) if v]
        if nz:
            parts = [f"{lbl}高达 {v:.0f}%" for lbl, v in nz]
            add_para(doc, f"但『已决+未决』满期赔付率显示{'、'.join(parts)}，"
                          f"即对应年度存在未决赔案，未决赔付率约 {nz[-1][1]:.0f}%。")
        if r['claim_count'] > 0:
            reasons = parse_reasons(r['claim_raw'])
            if reasons:
                rs = '、'.join(f"{n}{c}次" for n, c in reasons)
                add_para(doc, f"近3年共出险{r['claim_count']}次（{rs}）。")
            else:
                add_para(doc, f"近3年共出险{r['claim_count']}次。")
        if r['claim_amount'] > 0:
            add_para(doc, f"累计赔案金额约 {fmt_money(r['claim_amount'])}。")

    # ---------- 三、欺诈风险识别 ----------
    add_heading(doc, '三、欺诈风险识别')
    m0 = records[0]['m0']
    m2 = records[0]['m2']
    m3 = records[0]['m3']
    z = '0,0.00%'
    if m0 == m2 == m3 == z:
        add_para(doc, f"{ship}近1年起保当月、起保2个月、起保3个月的出险保单数量及占比均为"
                     f"『0,0.00%』，即近1年无早期出险记录，欺诈风险较低。")
    elif m0 != z:
        add_para(doc, f"{ship}近1年起保当月出险保单数量及占比为『{m0}』，并非『0,0.00%』，"
                     f"存在较高欺诈风险，需重点核查。")
    else:
        add_para(doc, f"{ship}近1年起保当月出险为『0,0.00%』，但起保2个月/3个月内存在出险记录，"
                     f"欺诈风险一般，建议保持关注。")
    n = records[0]['ins_count']
    code = records[0]['ins_code']
    name = org_map.get(code, code) if code else '未知'
    chg = (n - 1) if (n and n >= 1) else 0
    add_para(doc, f"近3年保单涉及保险公司数量为 {n} 家，存在 {chg} 次承保公司变更，"
                 f"最近一张保单承保公司为{name}。结合业务品质情况，建议进一步关注转保原因，"
                 f"排除高赔付业务转移的可能。")

    # ---------- 四、近3年单均保额保费 ----------
    add_heading(doc, '四、近3年单均保额保费')
    for r in records:
        sum_wan = r['avg_sum'] / 10000.0
        prem_wan = r['avg_prem'] / 10000.0
        rate = (r['avg_prem'] / r['avg_sum'] * 1000) if r['avg_sum'] else 0
        line = (f"{r['kind']}：单均保额 {sum_wan:.0f} 万，单均保费 {prem_wan:.2f} 万，"
                f"单均费率约 {rate:.2f}‰")
        if args.gt:
            line += f"（折合约 {r['avg_prem']/args.gt:.2f} 元/GT）"
        line += '。'
        add_para(doc, line)
    add_para(doc, '注：保赔险费率一般按总吨位计、船壳险按保额计，二者计算口径不同，'
                 '不宜直接横向比较。', size=10, color=GRAY)

    # ---------- 五、风险提示 ----------
    add_heading(doc, '五、风险提示')
    bq = judge_business(records)
    fr = judge_fraud(records)
    add_label_color(doc, '业务品质评估：', bq)
    add_label_color(doc, '欺诈风险评估：', fr)

    # ---------- 六、核保建议 ----------
    add_heading(doc, '六、核保建议')
    # 1) 未决赔案且字段为 (null) -> 口径出入（用户要求置于此处）
    for r in records:
        nz = [(lbl, v) for lbl, v in zip(YEAR_LABELS, r['adj_unpd']) if v and v > 0]
        is_null = (r['claim_raw'] is None or str(r['claim_raw']).strip() == '(null)')
        if nz and (is_null or r['claim_amount'] == 0):
            top = max(nz, key=lambda x: x[1])
            add_bullet(doc, f"{r['kind']}存在高额未决赔案（{top[0]}未决赔付率约 {top[1]:.0f}%），"
                           f"且『近3年出险原因及数量』『近3年赔案金额』字段均为 (null)，"
                           f"数据口径存在出入，建议核实数据来源并重点核查该未决赔案进展、"
                           f"估损金额及责任构成。")
    # 2) 有出险的险种
    for r in records:
        if r['claim_count'] > 0:
            add_bullet(doc, f"{r['kind']}近3年出险{r['claim_count']}次，累计赔案约 "
                           f"{fmt_money(r['claim_amount'])}，整体赔付水平需持续关注后续走势。")
    # 3) 转保关注
    if n and n >= 2:
        add_bullet(doc, f"近3年保单涉及 {n} 家保险公司（最近为{name}），存在转保，"
                       f"建议核实转保原因，排除高赔付业务转移可能。")
    # 4) 综合建议
    bq_txt = LEVEL[bq][0]
    fr_txt = LEVEL[fr][0]
    add_bullet(doc, f"欺诈风险评估为{fr_txt}、业务品质评估为{bq_txt}，"
                   f"建议谨慎核保、有条件承保，并将未决赔案作为重点跟踪项。")

    # ---------- 末尾左下角：日期与注 ----------
    add_para(doc, '')
    endp = doc.add_paragraph()
    endp.alignment = WD_ALIGN_PARAGRAPH.LEFT
    add_run(endp, f"报告生成日期：{args.date}\n"
                  f"注：本报告由 AI 生成，仅供内部参考，不作为最终核保依据。",
            size=9, color=GRAY)

    # ---------- 斜向水印 ----------
    add_slant_watermark(doc, args.watermark)

    # ---------- 保存（处理预览锁定） ----------
    if args.output:
        out = args.output
    else:
        base = os.path.join(os.path.dirname(os.path.abspath(args.query)),
                            f'{ship}智盾解读报告.docx')
        out = base
    try:
        doc.save(out)
    except PermissionError:
        out2 = os.path.splitext(base)[0] + '_' + time.strftime('%H%M%S') + '.docx'
        doc.save(out2)
        out = out2
    return out, bq, fr


def main():
    ap = argparse.ArgumentParser(description='船舶险智盾解读报告生成')
    ap.add_argument('--query', required=True, help='查询数据 xlsx（含目标船舶记录）')
    ap.add_argument('--ship', required=True, help='目标船舶中文名')
    ap.add_argument('--template', default=os.path.join(skill_assets(), '船舶险智盾报告模板.docx'))
    ap.add_argument('--org', default=os.path.join(skill_assets(), '机构代码表.xlsx'))
    ap.add_argument('--output', default=None, help='输出 docx 路径')
    ap.add_argument('--watermark', default=DEFAULT_WATERMARK, help='斜向水印文本')
    ap.add_argument('--gt', type=float, default=None, help='总吨位 GT（可选，用于元/GT）')
    ap.add_argument('--imo', default=None, help='IMO 号（可选，提供才显示）')
    ap.add_argument('--type', default=None, help='船舶类型（可选）')
    ap.add_argument('--id', default=None, help='船舶识别号（可选，覆盖查询文件）')
    _today = datetime.date.today()
    ap.add_argument('--date', default=f"{_today.year}年{_today.month}月{_today.day}日")
    args = ap.parse_args()

    records = load_records(args.query, args.ship)
    org_map = build_org_map(args.org)
    out, bq, fr = generate(args, records, org_map)
    print(f"已生成报告：{out}")
    print(f"业务品质评估：{LEVEL[bq][0]} | 欺诈风险评估：{LEVEL[fr][0]}")


if __name__ == '__main__':
    main()
